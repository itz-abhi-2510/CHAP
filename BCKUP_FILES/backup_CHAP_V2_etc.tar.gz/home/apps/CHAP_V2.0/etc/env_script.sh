module load papi/5.7.0
#module load compiler/hpc_sdk_22.11/nvhpc/22.11
module load compiler/intel/2020.4.304
module load python/3.7.11
#module load horovod_python/3.9
#module load cmake/3.15.4
#module load horovod_python/3.9

#export PATH=/home/apps/CHAP_V2.0/dependancy/gcc-12.2.0/build/bin:$PATH                  ######gcc -12.2.0  
#export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/gcc-12.2.0/build/lib:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/gcc-12.2.0/build/lib64:$LD_LIBRARY_PATH

###### Gcc -11.2.0
export PATH=/home/apps/CHAP_V2.0/dependancy/gcc-11_build/bin:$PATH
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/gcc-11_build/lib64:$LD_LIBRARY_PATH #installed 
######

export PATH=/home/apps/CHAP_V2.0/dependancy/cmake-3.31.8-linux-x86_64/bin:$PATH     ###cmake-3.31.8

export PATH=/home/apps/CHAP_V2.0/dependancy/make-4.4.1/build/bin:$PATH         ##3make-4.4.2 for glibc- 2.34
####

export PATH=/home/apps/CHAP_V2.0/dependancy/binutils_build/bin:$PATH
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/binutils_build/lib:$LD_LIBRARY_PATH

#####OpenBlash installation with cmake 3.31 

export CPATH=/home/apps/CHAP_V2.0/dependancy/openblash_install/include:$CPATH
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/openblash_install/lib64/:$LD_LIBRARY_PATH                          
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/OpenBLAS/build/lib:$LD_LIBRARY_PATH

#######
export PATH=/home/apps/CHAP_V2.0/dependancy/curl_build/bin:$PATH
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/curl_build/lib:$LD_LIBRARY_PATH
##########
export PATH=/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin:$PATH

#module load cmake/3.15.4
#export PATH=/home/chap/chap-v2/cmake-3.31.6-linux-x86_64/bin:$PATH

#export PATH=/home/chap/TAU/chap-v2/pdtoolkit-3.25.2/x86_64/bin:$PATH
#export LD_LIBRARY_PATH=/home/chap/TAU/chap-v2/pdtoolkit-3.25.2/x86_64/lib:$LD_LIBRARY_PATH

#export PATH=/home/chap/TAU/chap-v2/nvhpc_2024_247_Linux_x86_64_cuda_12.5/Linux_x86_64/24.7/compilers/bin:$PATH
#export LD_LIBRARY_PATH=/home/chap/TAU/chap-v2/nvhpc_2024_247_Linux_x86_64_cuda_12.5/Linux_x86_64/24.7/compilers/lib:$LD_LIBRARY_PATH

export PATH=/home/apps/CHAP_V2.0/dependancy/pdtoolkit-3.25.2/x86_64/bin:$PATH
export LD_LIBRRAY_PATH=/home/apps/CHAP_V2.0/dependancy/pdtoolkit-3.25.2/x86_64/lib:$LD_LIBRARY_PATH

export PATH=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/bin:$PATH
export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/lib:$LD_LIBRARY_PATH
export TAU_MAKEFILE=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/lib/Makefile.tau-openmpi-icpc-papi-ompt-mpi-pthread-pdt-openmp


#export PATH=/home/apps/CHAP_V2.0/dependancy/pdtoolkit-3.25.2/x86_64/bin:$PATH
#export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/pdtoolkit-3.25.2/x86_64/lib:$LD_LIBRARY_PATH

#export PATH=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/bin:$PATH
#export LD_LIBRARY_PATH=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/lib:$LD_LIBRARY_PATH
#export TAU_MAKEFILE=/home/apps/CHAP_V2.0/dependancy/tau-2.34/x86_64/lib/Makefile.tau-openmpi-icpc-papi-ompt-mpi-pthread-pdt-openmp


#export PATH=/home/chap/TAU/chap-v2/tau-2.34/x86_64/bin:$PATH
#export LD_LIBRARY_PATH=/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib:$LD_LIBRARY_PATH

#export TAU_MAKEFILE=/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib/Makefile.tau-openmpi-icpc-papi-ompt-mpi-pdt-openmp


### for openmp mpi fortran ####

#export TAU_MAKEFILE=/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib/Makefile.tau-openmpi-icpc-papi-ompt-mpi-pdt-openmp ###for openmp mpi fortran####

### for cuda fortran and cuda c ###

#export TAU_MAKEFILE=/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib/Makefile.tau-cupti-openmpi-papi-mpi-pthread-pdt-openmp #for cuda 


