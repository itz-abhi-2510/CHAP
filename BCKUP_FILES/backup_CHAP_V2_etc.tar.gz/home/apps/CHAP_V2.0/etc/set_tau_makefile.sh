#!/bin/bash

# Function to set TAU_MAKEFILE
set_tau_makefile() {
    echo "Select the type of application:"
    echo "1. Fortran / OpenMP / MPI"
    echo "2. CUDA Fortran / CUDA C"
    read -p "Enter your choice (1/2): " app_type

    if [ "$app_type" == "1" ]; then
        export TAU_MAKEFILE="/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib/Makefile.tau-openmpi-icpc-papi-ompt-mpi-pdt-openmp"
	export OMP_NUM_THREADS=4
        

    elif [ "$app_type" == "2" ]; then
        export TAU_MAKEFILE="/home/chap/TAU/chap-v2/tau-2.34/x86_64/lib/Makefile.tau-cupti-openmpi-papi-mpi-pthread-pdt-openmp"
    else
        echo "Invalid choice. Exiting."
        exit 1
    fi

    # Verify that TAU_MAKEFILE is set
    if [ -z "$TAU_MAKEFILE" ]; then
        echo "Error: TAU_MAKEFILE is not set. Exiting."
        exit 1
    else
	echo $TAU_MAKEFILE
        #echo "TAU_MAKEFILE is set to: $TAU_MAKEFILE"
    fi
}

# Call the function
set_tau_makefile

