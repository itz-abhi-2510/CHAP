#include <stdio.h>
#include <omp.h>

double calculate_pi(int num_intervals, int num_threads) {
    double step = 1.0 / num_intervals;
    double sum = 0.0;

    #pragma omp parallel reduction(+:sum) num_threads(num_threads)
    {
        int i;
        double local_sum = 0.0;

        for (i = 0; i < num_intervals; i++) {
            double x = (i + 0.5) * step;
            local_sum += 4.0 / (1.0 + x * x);
        }

        sum += local_sum; // Each thread accumulates safely with reduction
    }

    return sum * step;
}

