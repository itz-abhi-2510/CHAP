#include <stdio.h>
#include <omp.h>

// Function declaration
double calculate_pi(int num_intervals, int num_threads);

int main() {
    int num_intervals = 10000; // Hardcoded value
    int num_threads = 4;           // Hardcoded value

    printf("Number of intervals: %d\n", num_intervals);
    printf("Number of threads: %d\n", num_threads);

    double start_time = omp_get_wtime();  // Start timing

    double pi = calculate_pi(num_intervals, num_threads);

    double end_time = omp_get_wtime();  // End timing

    printf("Calculated value of π: %.15f\n", pi);
    printf("Total execution time: %f seconds\n", end_time - start_time);

    return 0;
}
