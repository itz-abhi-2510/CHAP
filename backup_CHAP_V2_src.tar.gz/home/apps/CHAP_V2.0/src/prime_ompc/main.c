#include <omp.h>
#include <stdio.h>

/* External function declarations */
extern void compute_primes_tasked(int, int, int *);
extern void compute_trigonometry_tasked(int, double *);
extern void print_stats(int, double, double);

#define PRIME_LIMIT 200000
#define TRIG_ITER   10000000

int main() {
    int prime_count;
    double trig_sum;
    double start, end;

    prime_count = 0;
    trig_sum = 0.0;

    omp_set_num_threads(8);

    start = omp_get_wtime();

    #pragma omp parallel sections
    {
        #pragma omp section
        {
            compute_primes_tasked(2, PRIME_LIMIT, &prime_count);
        }

        #pragma omp section
        {
            compute_trigonometry_tasked(TRIG_ITER, &trig_sum);
        }
    }

    end = omp_get_wtime();

    print_stats(prime_count, trig_sum, end - start);

    return 0;
}
