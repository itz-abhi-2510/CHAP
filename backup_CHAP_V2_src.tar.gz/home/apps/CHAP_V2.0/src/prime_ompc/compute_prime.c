#include <omp.h>

extern int is_prime(int);

#define CHUNK 1000

void compute_primes_tasked(int start, int end, int *count) {
    int total;
    int i, j;
    int s, e;

    total = 0;

    #pragma omp parallel
    {
        int local;
        local = 0;

        #pragma omp single
        {
            for (i = start; i <= end; i += CHUNK) {
                s = i;
                e = i + CHUNK - 1;
                if (e > end)
                    e = end;

                #pragma omp task firstprivate(s, e)
                {
                    int tmp;
                    tmp = 0;

                    for (j = s; j <= e; j++) {
                        if (is_prime(j))
                            tmp++;
                    }

                    #pragma omp atomic
                    local += tmp;
                }
            }
        }

        #pragma omp taskwait

        #pragma omp atomic
        total += local;
    }

    *count = total;
}

