#include <math.h>
#include <stdlib.h>

int is_prime(int num) {
    int i;

    if (num <= 1)
        return 0;

    for (i = 2; i <= sqrt(num); i++) {
        if (num % i == 0)
            return 0;
    }
    return 1;
}

double random_double() {
    return (double)rand() / RAND_MAX;
}
