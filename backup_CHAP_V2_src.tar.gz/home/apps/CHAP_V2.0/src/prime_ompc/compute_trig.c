#include <omp.h>
#include <math.h>

extern double random_double();

#define CHUNK 1000

void compute_trigonometry_tasked(int n, double *sum) {
    int i, j;
    int s, e;
    double total;

    total = 0.0;

    #pragma omp parallel
    {
        double local;
        local = 0.0;

        #pragma omp single
        {
            for (i = 0; i < n; i += CHUNK) {
                s = i;
                e = i + CHUNK;
                if (e > n)
                    e = n;

                #pragma omp task firstprivate(s, e)
                {
                    double tmp;
                    tmp = 0.0;

                    for (j = s; j < e; j++) {
                        double x;
                        x = random_double();
                        tmp += sin(x) * cos(x);
                    }

                    #pragma omp atomic
                    local += tmp;
                }
            }
        }

        #pragma omp taskwait

        #pragma omp atomic
        total += local;
    }

    *sum = total;
}

