#include <stdio.h>

void print_stats(int prime_count, double trig_sum, double time) {
    printf("\n==== OpenMP Sections + Tasks ====\n");
    printf("Prime numbers found : %d\n", prime_count);
    printf("Trig computation   : %lf\n", trig_sum);
    printf("Execution time     : %lf sec\n", time);
    printf("================================\n");
}
