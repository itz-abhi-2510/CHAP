#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define N 10000000  // Total number of iterations

int main(int argc, char *argv[]) {
    int rank, size;
    double local_sum = 0.0, total_sum = 0.0;
    double start_time, end_time;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Determine workload for each process
    int chunk_size = N / size;
    int start = rank * chunk_size;
    int end = (rank == size - 1) ? N : start + chunk_size;
    int i; 
    start_time = MPI_Wtime();

    // 🔥 HOTSPOT: heavy computation
    for (i = start; i < end; i++) {
        local_sum += sin(i) * sin(i);  // Profiling will show this as hotspot
    }

    MPI_Reduce(&local_sum, &total_sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    end_time = MPI_Wtime();

    if (rank == 0) {
        printf("Total sum of sin(i)^2 = %f\n", total_sum);
        printf("Execution time: %f seconds\n", end_time - start_time);
    }

    MPI_Finalize();
    return 0;
}
