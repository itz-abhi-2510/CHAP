! prime_openmp.f90
module prime_module
    implicit none
contains
    function is_prime(num) result(prime)
        integer, intent(in) :: num
        logical :: prime
        integer :: j
        prime = .true.
        if (num < 2) then
            prime = .false.
            return
        end if
        do j = 2, int(sqrt(real(num)))
            if (mod(num, j) == 0) then
                prime = .false.
                return
            end if
        end do
    end function is_prime 
end module prime_module
