program prime_openmp
    use omp_lib
    use prime_module
    implicit none
    integer :: n
    integer :: i  ! Ensure variable is declared before assignment

    n = 100  ! Hardcoded upper limit

    print *, 'Finding prime numbers up to:', n

    !$omp parallel do private(i) shared(n) schedule(dynamic)
    do i = 2, n
        if (is_prime(i)) then
            print *, i
        end if
    end do
    !$omp end parallel do

end program prime_openmp
