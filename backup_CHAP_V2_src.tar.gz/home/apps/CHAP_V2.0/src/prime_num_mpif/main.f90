! main.f90
program mpi_prime_count
    use mpi
    implicit none

    integer :: ierr, rank, size
    integer :: N, i, local_count, global_count
    integer :: start_num, end_num

    external :: is_prime
    external :: compute_range

    ! Initialize MPI
    call MPI_Init(ierr)
    call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)
    call MPI_Comm_size(MPI_COMM_WORLD, size, ierr)

    ! Only rank 0 asks user for N
    if (rank == 0) then
        print *, 'Enter the upper limit N:'
        read(*,*) N
    end if

    ! Broadcast N to all processes
    call MPI_Bcast(N, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)

    ! Compute this process’s range
    call compute_range(rank, size, N, start_num, end_num)

    ! Count primes in the assigned range
    local_count = 0
    
    do i = start_num, end_num
        if (is_prime(i)) local_count = local_count + 1
    end do

    ! Sum up all local counts into global count
    call MPI_Reduce(local_count, global_count, 1, MPI_INTEGER, MPI_SUM, 0, MPI_COMM_WORLD, ierr)

    if (rank == 0) then
        print *, 'Total number of primes between 2 and', N, 'is', global_count
    end if

    call MPI_Finalize(ierr)
end program mpi_prime_count
