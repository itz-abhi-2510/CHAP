module heat_solver
  use mpi
  implicit none
  integer, parameter :: dp = kind(1.0d0)
contains
  subroutine exchange_halos(u, nx, ny_local, rank, nprocs, comm)
    real(dp), intent(inout) :: u(0:nx+1,0:ny_local+1)
    integer, intent(in) :: nx, ny_local, rank, nprocs, comm
    integer :: up, down, ierr
    up   = rank-1
    down = rank+1

    ! top halo
    if (up >= 0) then
      call MPI_Sendrecv(u(1,1), nx, MPI_DOUBLE_PRECISION, up, 0, &
                        u(1,0), nx, MPI_DOUBLE_PRECISION, up, 1, comm, MPI_STATUS_IGNORE, ierr)
    else
      u(1:nx,0) = 0.0_dp
    end if

    ! bottom halo
    if (down < nprocs) then
      call MPI_Sendrecv(u(1,ny_local), nx, MPI_DOUBLE_PRECISION, down, 1, &
                        u(1,ny_local+1), nx, MPI_DOUBLE_PRECISION, down, 0, comm, MPI_STATUS_IGNORE, ierr)
    else
      u(1:nx,ny_local+1) = 0.0_dp
    end if
  end subroutine exchange_halos

  subroutine step(u, uold, nx, ny_local, dx, dy, dt, alpha)
    real(dp), intent(inout) :: u(0:nx+1,0:ny_local+1)
    real(dp), intent(in)    :: uold(0:nx+1,0:ny_local+1)
    integer, intent(in)     :: nx, ny_local
    real(dp), intent(in)    :: dx, dy, dt, alpha
    integer :: i, j
    real(dp) :: cx, cy

    cx = alpha*dt/dx**2
    cy = alpha*dt/dy**2

    do j=1,ny_local
      do i=1,nx
        u(i,j) = uold(i,j) + cx*(uold(i+1,j)-2*uold(i,j)+uold(i-1,j)) + &
                              cy*(uold(i,j+1)-2*uold(i,j)+uold(i,j-1))
      end do
    end do
  end subroutine step
end module heat_solver

