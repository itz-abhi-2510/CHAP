module io_mod
  use mpi
  implicit none
  integer, parameter :: dp = kind(1.0d0)
contains
  subroutine write_snapshot(u, nx, ny_local, rank, comm, stepnum)
    real(dp), intent(in) :: u(0:nx+1,0:ny_local+1)
    integer, intent(in)  :: nx, ny_local, rank, comm, stepnum
    integer :: ierr

    ! Just write one file per rank (simpler than gather)
    character(len=30) :: fname
    write(fname,'("snap_",I4.4,"_rank",I3.3,".dat")') stepnum, rank
    open(unit=20,file=fname,status="replace")
    write(20,'(100f10.4)') u
    close(20)
  end subroutine write_snapshot
end module io_mod
