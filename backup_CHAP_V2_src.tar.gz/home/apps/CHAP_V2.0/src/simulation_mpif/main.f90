program heat_mpi
  use mpi
  use mesh_mod         ! already defines dp
  use heat_solver      ! also uses dp
  use io_mod           ! also uses dp
  implicit none
  integer :: rank, nprocs, ierr, comm
  integer :: nx, ny, ny_local, nsteps, t
  real(dp), allocatable :: u(:,:), uold(:,:)
  real(dp) :: dx, dy, dt, alpha

  call MPI_Init(ierr)
  comm = MPI_COMM_WORLD
  call MPI_Comm_rank(comm, rank, ierr)
  call MPI_Comm_size(comm, nprocs, ierr)

  ! simple parameters
  nx = 50
  ny = 50
  nsteps = 100
  dx = 1.0_dp; dy = 1.0_dp; dt = 0.1_dp; alpha = 0.1_dp

  ! assume divisible
  ny_local = ny/nprocs

  call allocate_fields(nx, ny_local, u, uold)

  ! initialize
  u = 0.0_dp
  uold = 0.0_dp
  if (rank == 0) u(nx/2, ny_local/2) = 100.0_dp

  do t=1,nsteps
    call exchange_halos(uold, nx, ny_local, rank, nprocs, comm)
    call step(u, uold, nx, ny_local, dx, dy, dt, alpha)
    uold = u
    if (mod(t,20)==0) call write_snapshot(u, nx, ny_local, rank, comm, t)
  end do

  call MPI_Finalize(ierr)
end program heat_mpi
