module mesh_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
contains
  subroutine allocate_fields(nx, ny_local, u, uold)
    integer, intent(in) :: nx, ny_local
    real(dp), allocatable, intent(out) :: u(:,:), uold(:,:)
    allocate(u(0:nx+1,0:ny_local+1))
    allocate(uold(0:nx+1,0:ny_local+1))
    u = 0.0_dp
    uold = 0.0_dp
  end subroutine allocate_fields
end module mesh_mod
