module thetables

   integer, parameter :: i6 = selected_int_kind(6)
   integer, parameter :: r9 = selected_real_kind(9)

contains

   subroutine prime_table(prime_num, primes)
      implicit none
      integer(kind=i6) prime_num
      integer(kind=i6) primes(prime_num)
      integer(kind=i6) i, j, p
      logical prime

      i = 2
      p = 0

      do while (p < prime_num)
         prime = .true.
         do j = 2, i - 1
            if (mod(i, j) == 0) then
               prime = .false.
               exit
            end if
         end do
         if (prime) then
            p = p + 1
            primes(p) = i
         end if
         i = i + 1
      end do

   end subroutine prime_table

   subroutine sine_table(sine_num, sines)
      implicit none
      integer(kind=i6) sine_num
      real(kind=r9) sines(sine_num)
      real(kind=r9) a
      integer(kind=i6) i, j
      real(kind=r9), parameter :: r8_pi = 3.141592653589793D+00

      do i = 1, sine_num
         sines(i) = 0.0D+00
         do j = 1, i
            a = real(j - 1, kind=r9)*r8_pi/real(sine_num - 1, kind=r9)
            sines(i) = sines(i) + sin(a)
         end do
      end do

   end subroutine sine_table

   subroutine cosine_table(cosine_num, cosines)
      implicit none
      integer(kind=i6) cosine_num
      real(kind=r9) cosines(cosine_num)
      real(kind=r9) a
      integer(kind=i6) i, j
      real(kind=r9), parameter :: r8_pi = 3.141592653589793D+00

      do i = 1, cosine_num
         cosines(i) = 0.0D+00
         do j = 1, i
            a = real(j - 1, kind=r9)*r8_pi/real(cosine_num - 1, kind=r9)
            cosines(i) = cosines(i) + cos(a)   ! ✅ FIXED: using cos
         end do
      end do

   end subroutine cosine_table

end module thetables
