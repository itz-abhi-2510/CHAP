subroutine timestamp()
  implicit none
  character(len=8) :: ampm
  integer :: d, h, m, mm, n, s, values(8), y
  character(len=9), parameter, dimension(12) :: month = (/ &
    'January  ', 'February ', 'March    ', 'April    ', &
    'May      ', 'June     ', 'July     ', 'August   ', &
    'September', 'October  ', 'November ', 'December ' /)

  call date_and_time(values = values)
  y = values(1); m = values(2); d = values(3)
  h = values(5); n = values(6); s = values(7); mm = values(8)

  if (h < 12) then
    ampm = 'AM'
  else if (h == 12) then
    if (n == 0 .and. s == 0) then
      ampm = 'Noon'
    else
      ampm = 'PM'
    end if
  else
    h = h - 12
    if (h < 12) then
      ampm = 'PM'
    else if (h == 12) then
      if (n == 0 .and. s == 0) then
        ampm = 'Midnight'
      else
        ampm = 'AM'
      end if
    end if
  end if

  write (*,'(i2.2,1x,a,1x,i4,2x,i2,a1,i2.2,a1,i2.2,a1,i3.3,1x,a)') &
    d, trim(month(m)), y, h, ':', n, ':', s, '.', mm, trim(ampm)
end subroutine timestamp
