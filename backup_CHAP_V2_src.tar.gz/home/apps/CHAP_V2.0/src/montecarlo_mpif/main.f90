program monte_carlo_main
  use mpi
  implicit none

  ! Declarations
  integer(kind=4), parameter :: chunk_size = 1000
  integer(kind=4) :: done, dummy = 0, i, id, ierr
  integer(kind=4) :: in_local, in_total, num_procs
  integer(kind=4) :: out_local, out_total
  integer(kind=4) :: point_local, point_total, point_max = 1000000
  integer(kind=4) :: ranks(1), requestor, server
  integer(kind=4) :: status(MPI_STATUS_SIZE)
  integer(kind=4) :: tag, worker_comm, worker_group, world_group
  real(kind=8)    :: pi_est, error, tolerance
  real(kind=8), parameter :: pi_true = 3.141592653589793238462643d0
  real(kind=8)    :: rands(chunk_size), x, y
  integer(kind=4), parameter :: tag_exit = 0
  integer(kind=4), parameter :: tag_random_send = 1
  integer(kind=4), parameter :: tag_random_sent = 2

  ! Initialize MPI
  call MPI_Init(ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, num_procs, ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, id, ierr)

  ! Master prints intro
  if (id == 0) then
    call timestamp()
    write (*,*) " "
    write (*,*) "MONTE_CARLO_MPI:"
    write (*,*) "  FORTRAN90 version"
    write (*,*) " "
    write (*,*) "  An MPI example program to estimate PI by Monte Carlo."
    write (*,'(a,i8)') "  The number of processes is ", num_procs
    write (*,*) "  Points in the unit square will be tested for quarter circle."
  end if

  write (*,'(a,i3,a)') "  Process ", id, " is active."

  if (id == 0) then
    tolerance = 0.001d0
    write (*,*) " "
    write (*,*) "  The method continues until:"
    write (*,'(a,g14.6)') "  PI is computed to tolerance = ", tolerance
    write (*,'(a,i9)') "  or number of points reaches ", point_max
  end if

  ! Broadcast tolerance
  call MPI_Bcast(tolerance, 1, MPI_DOUBLE_PRECISION, 0, MPI_COMM_WORLD, ierr)

  ! Define server as last rank
  server = num_procs - 1
  if (id == 0) then
    write (*,*) " "
    write (*,*) "MONTE_CARLO_MPI - Master process:"
    write (*,'(a,i8)') "  The random number server process ID is ", server
  end if

  ! Create worker communicator (exclude server)
  call MPI_Comm_group(MPI_COMM_WORLD, world_group, ierr)
  ranks(1) = server
  call MPI_Group_excl(world_group, 1, ranks, worker_group, ierr)
  call MPI_Comm_create(MPI_COMM_WORLD, worker_group, worker_comm, ierr)
  call MPI_Group_free(worker_group, ierr)

  ! Computation phase
  if (id == server) then
    ! SERVER code
    do
      tag = MPI_ANY_TAG
      call MPI_Recv(dummy, 1, MPI_INTEGER, MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, status, ierr)
      tag = status(MPI_TAG)

      if (tag == tag_exit) exit
      requestor = status(MPI_SOURCE)

      call random_number(rands(1:chunk_size))
      tag = tag_random_sent
      call MPI_Send(rands, chunk_size, MPI_DOUBLE_PRECISION, requestor, tag, MPI_COMM_WORLD, ierr)
    end do

  else
    ! WORKER code
    in_local = 0
    out_local = 0
    point_local = 0

    do
      tag = tag_random_send
      call MPI_Send(dummy, 1, MPI_INTEGER, server, tag, MPI_COMM_WORLD, ierr)
      call MPI_Recv(rands, chunk_size, MPI_DOUBLE_PRECISION, server, MPI_ANY_TAG, MPI_COMM_WORLD, status, ierr)

      do i = 1, chunk_size, 2
        x = rands(i)
        y = rands(i+1)
        point_local = point_local + 1
        if (x**2 + y**2 <= 1.0d0) then
          in_local = in_local + 1
        else
          out_local = out_local + 1
        end if
      end do

      call MPI_Reduce(in_local, in_total, 1, MPI_INTEGER, MPI_SUM, 0, worker_comm, ierr)
      call MPI_Reduce(out_local, out_total, 1, MPI_INTEGER, MPI_SUM, 0, worker_comm, ierr)
      call MPI_Reduce(point_local, point_total, 1, MPI_INTEGER, MPI_SUM, 0, worker_comm, ierr)

      if (id == 0) then
        pi_est = 4.0d0 * in_total / point_total
        error  = abs(pi_est - pi_true)
        done   = 1

        if (error < tolerance .or. point_total >= point_max) then
          done = 0
          tag  = tag_exit
          call MPI_Send(dummy, 1, MPI_INTEGER, server, tag, MPI_COMM_WORLD, ierr)
        end if
      end if

      call MPI_Bcast(done, 1, MPI_INTEGER, 0, worker_comm, ierr)
      if (done == 0) exit
    end do
  end if

  ! Final output
  if (id == 0) then
    write (*,*) " "
    write (*,*) "MONTE_CARLO_MPI - Master process:"
    write (*,'(a,g24.16)') "  Estimate for PI = ", pi_est
    write (*,'(a,g14.6)') "  Error = ", error
    write (*,'(a,i8)') "  Number of points = ", point_total
  end if

  ! Free communicator safely
  if (worker_comm /= MPI_COMM_NULL) then
    call MPI_Comm_free(worker_comm, ierr)
  end if

  ! Shutdown
  call MPI_Finalize(ierr)
  if (id == 0) then
    write (*,*) " "
    write (*,*) "MONTE_CARLO_MPI - Master process:"
    write (*,*) "  Normal end of execution."
    call timestamp()
  end if

end program monte_carlo_main
