//main.c
#include <stdio.h>
#include <omp.h>

//Function prototype (no header file used)
int is_prime(int n);

int main() {
    int max_number = 100000;   // 1 lakh
    int i,count = 0;
    double start_time, end_time;

    start_time = omp_get_wtime();

    #pragma omp parallel for reduction(+:count) schedule(dynamic)
    for (i = 2; i <= max_number; i++) {
        if (is_prime(i)) {
            count++;
        }
    }

    end_time = omp_get_wtime();

    printf("Total prime numbers found up to %d: %d\n", max_number, count);
    printf("Time taken: %f seconds\n", end_time - start_time);

    return 0;
}

