module pi_module
    implicit none
contains
    function calculate_pi(n, num_threads) result(pi)
        use omp_lib
        implicit none
        integer, intent(in) :: n, num_threads
        real(8) :: pi, dx, sum, x
        integer :: i

        pi = 0.0d0
        dx = 1.0d0 / dble(n)
        sum = 0.0d0

        !$omp parallel do private(x) reduction(+:sum) num_threads(num_threads)
        do i = 1, n
            x = (dble(i) - 0.5d0) * dx
            sum = sum + 4.0d0 / (1.0d0 + x * x)
        end do
        !$omp end parallel do

        pi = sum * dx
    end function calculate_pi
end module pi_module
