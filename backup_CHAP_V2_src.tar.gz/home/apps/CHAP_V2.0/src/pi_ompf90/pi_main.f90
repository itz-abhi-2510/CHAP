program pi_openmp
    use omp_lib
    use pi_module  ! Use the module that contains the function
    implicit none
    integer, parameter :: num_intervals = 10000
    integer, parameter :: num_threads = 4
    double precision :: pi, start_time, end_time

    ! Function declaration
!    double precision :: calculate_pi
!    external calculate_pi

    print *, 'Number of intervals:', num_intervals
    print *, 'Number of threads:', num_threads

    start_time = omp_get_wtime()
    pi = calculate_pi(num_intervals, num_threads)
    end_time = omp_get_wtime()

    print *, 'Calculated value of π:', pi
    print *, 'Total execution time:', end_time - start_time

end program pi_openmp
