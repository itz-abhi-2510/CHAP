#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

// Function declarations (normally in header, but inline here)
void allocate_matrices(int ***A, int ***B, int ***C, int N);
void initialize_matrices(int **A, int **B, int N);
void multiply_matrices_parallel(int **A, int **B, int **C, int N);
void free_matrices(int **A, int **B, int **C, int N);

int main() {
    int N = 1000; // Size of the matrix
    int **A, **B, **C;

    allocate_matrices(&A, &B, &C, N);
    initialize_matrices(A, B, N);

    double start_time = omp_get_wtime();
    multiply_matrices_parallel(A, B, C, N);
    double end_time = omp_get_wtime();

    printf("Matrix multiplication completed in %f seconds.\n", end_time - start_time);

    free_matrices(A, B, C, N);
    return 0;
}
