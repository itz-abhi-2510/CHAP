#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include "utils.h"

double* allocate_array(int n) {
    double *arr = (double *)malloc(sizeof(double) * n);
    if (!arr) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return arr;
}

void initialize_arrays(double *a, double *b, int n) {
    int i;
    #pragma omp parallel for
    for (i = 0; i < n; i++) {
        a[i] = i * 1.0;
        b[i] = (n - i) * 0.5;
    }
}

