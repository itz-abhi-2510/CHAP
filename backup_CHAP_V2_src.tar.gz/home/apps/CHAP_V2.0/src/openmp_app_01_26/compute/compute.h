#ifndef COMPUTE_H
#define COMPUTE_H

void vector_add(double *a, double *b, double *c, int n);

#endif

