#ifndef UTILS_H
#define UTILS_H

double* allocate_array(int n);
void initialize_arrays(double *a, double *b, int n);

#endif

