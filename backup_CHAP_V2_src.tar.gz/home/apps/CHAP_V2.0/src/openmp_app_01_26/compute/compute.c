#include <omp.h>
#include "compute.h"

void vector_add(double *a, double *b, double *c, int n)
{
    int i;

    #pragma omp parallel for 
    {
       for (i = 0; i < n; i++)
      {
        c[i] = a[i] + b[i];
      }
    }

}
