#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include "compute.h"
#include "utils.h"

int main(int argc, char *argv[]) {
    int n = 10000000;

    if (argc > 1) {
        n = atoi(argv[1]);
    }

    double *a = allocate_array(n);
    double *b = allocate_array(n);
    double *c = allocate_array(n);

    initialize_arrays(a, b, n);

    double start = omp_get_wtime();
    vector_add(a, b, c, n);
    double end = omp_get_wtime();

    printf("Vector addition completed in %f seconds\n", end - start);
    printf("Sample output c[100] = %f\n", c[100]);

    free(a);
    free(b);
    free(c);

    return 0;
}

