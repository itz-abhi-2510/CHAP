#ifndef JACOBI_H
#define JACOBI_H

void jacobi(double *A, double *Anew, int n, int iters);

#endif

