#ifndef GRID_H
#define GRID_H

double* alloc_grid(int n);
void init_grid(double *A, int n);

#endif

