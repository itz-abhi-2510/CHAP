#include <omp.h>
#include "jacobi.h"

void jacobi(double *A, double *Anew, int n, int iters) {
    for (int iter = 0; iter < iters; iter++) {
        #pragma omp parallel for collapse(2)
        for (int i = 1; i < n-1; i++) {
            for (int j = 1; j < n-1; j++) {
                Anew[i*n+j] = 0.25 * (
                    A[(i-1)*n+j] + A[(i+1)*n+j] +
                    A[i*n+j-1] + A[i*n+j+1]
                );
            }
        }

        #pragma omp parallel for
        for (int i=0;i<n*n;i++)
            A[i] = Anew[i];
    }
}

