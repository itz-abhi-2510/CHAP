#include <stdlib.h>
#include <stdio.h>
#include "grid.h"

double* alloc_grid(int n) {
    double *A = (double*)malloc(sizeof(double)*n*n);
    if (!A) {
        printf("Allocation failed\n");
        exit(1);
    }
    return A;
}

void init_grid(double *A, int n) {
    for (int i=0;i<n*n;i++)
        A[i] = 0.0;

    for (int i=0;i<n;i++) {
        A[i] = 1.0;
        A[i*n] = 1.0;
        A[i*n + n-1] = 1.0;
        A[(n-1)*n + i] = 1.0;
    }
}

