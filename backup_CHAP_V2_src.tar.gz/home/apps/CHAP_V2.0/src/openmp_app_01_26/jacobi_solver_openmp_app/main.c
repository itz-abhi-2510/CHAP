#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include "jacobi.h"
#include "grid.h"

int main(int argc, char **argv) {
    int n = 8000;
    int iters = 20000;

    if (argc > 1) n = atoi(argv[1]);
    if (argc > 2) iters = atoi(argv[2]);

    double *A = alloc_grid(n);
    double *Anew = alloc_grid(n);

    init_grid(A, n);

    double t0 = omp_get_wtime();
    jacobi(A, Anew, n, iters);
    double t1 = omp_get_wtime();

    printf("Jacobi runtime: %f seconds\n", t1 - t0);

    free(A);
    free(Anew);
    return 0;
}

