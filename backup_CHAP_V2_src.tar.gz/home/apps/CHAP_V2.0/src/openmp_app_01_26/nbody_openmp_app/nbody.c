#include <math.h>
#include <omp.h>
#include "nbody.h"

#define G 6.674e-11
#define DT 0.01

void simulate(body_t *bodies, int n, int steps) {
    for (int s = 0; s < steps; s++) {
        #pragma omp parallel for schedule(dynamic)
        for (int i = 0; i < n; i++) {
            double fx = 0, fy = 0, fz = 0;
            for (int j = 0; j < n; j++) {
                if (i == j) continue;
                double dx = bodies[j].x - bodies[i].x;
                double dy = bodies[j].y - bodies[i].y;
                double dz = bodies[j].z - bodies[i].z;
                double dist = sqrt(dx*dx + dy*dy + dz*dz) + 1e-9;
                fx += dx / dist;
                fy += dy / dist;
                fz += dz / dist;
            }
            bodies[i].vx += fx * DT;
            bodies[i].vy += fy * DT;
            bodies[i].vz += fz * DT;
        }
    }
}

