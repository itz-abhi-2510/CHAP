#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include "nbody.h"

int main(int argc, char **argv) {
    int n = 20000;
    int steps = 1000;

    if (argc > 1) n = atoi(argv[1]);
    if (argc > 2) steps = atoi(argv[2]);

    body_t *bodies = malloc(sizeof(body_t) * n);

    for (int i=0;i<n;i++) {
        bodies[i].x = rand()%100;
        bodies[i].y = rand()%100;
        bodies[i].z = rand()%100;
    }

    double t0 = omp_get_wtime();
    simulate(bodies, n, steps);
    double t1 = omp_get_wtime();

    printf("N-body runtime: %f seconds\n", t1 - t0);
    free(bodies);
}

