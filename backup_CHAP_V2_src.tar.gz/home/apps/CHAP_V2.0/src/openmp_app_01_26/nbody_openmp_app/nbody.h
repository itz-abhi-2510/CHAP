#ifndef NBODY_H
#define NBODY_H

typedef struct {
    double x, y, z;
    double vx, vy, vz;
} body_t;

void simulate(body_t *bodies, int n, int steps);

#endif

