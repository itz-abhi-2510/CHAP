#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

// Forward declaration (since we're not using a header)
int is_prime(int num);

int main(int argc, char *argv[]) {
    int rank, size, limit;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc != 2) {
        if (rank == 0)
            printf("Usage: %s <limit>\n", argv[0]);
        MPI_Finalize();
        return 1;
    }

    limit = atoi(argv[1]);

    int chunk = limit / size;
    int start = rank * chunk;
    int end = (rank == size - 1) ? limit : start + chunk;

    if (start < 2) start = 2;

    int local_count = 0;

    for (int i = start; i < end; i++) {
        if (is_prime(i)) {
            local_count++;
        }
    }

    int total_count = 0;
    MPI_Reduce(&local_count, &total_count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Total number of prime numbers up to %d is %d\n", limit, total_count);
    }

    MPI_Finalize();
    return 0;
}
