#include <stdio.h>
#include <mpi.h>

// Function prototype
int count_primes(int start, int end);

int main(int argc, char **argv) {
    int rank, size;
    int limit = 100;  // Upper limit to find prime numbers

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int range_size = limit / size;
    int start = rank * range_size + 1;
    int end = (rank == size - 1) ? limit : start + range_size - 1;

    int local_count = count_primes(start, end);

    if (rank == 0) {
        int i, total_count = local_count;
        for (i = 1; i < size; i++) {
            int received_count;
            MPI_Recv(&received_count, 1, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total_count += received_count;
        }
        printf("Total prime numbers up to %d: %d\n", limit, total_count);
    } else {
        MPI_Send(&local_count, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Finalize();
    return 0;
}
