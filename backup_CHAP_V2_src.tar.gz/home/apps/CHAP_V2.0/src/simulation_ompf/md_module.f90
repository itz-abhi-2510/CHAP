module md
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer, parameter :: n = 1000
  real(dp), parameter :: dt = 0.01d0
  real(dp), parameter :: mass = 1.0d0
  real(dp), parameter :: k = 1.0d0
  real(dp), parameter :: box = 10.0d0

  real(dp), dimension(n) :: x, v, f
end module md
