program md_simulation
  use md
  use integration_md
  implicit none
  integer :: i, steps

  steps = 1000
  call initialize()
  call compute()

  do i = 1, steps
    call verlet()
    call print_results(i)
  end do
end program md_simulation
