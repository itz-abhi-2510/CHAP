module integration_md
  use md
  implicit none
contains

  subroutine initialize()
    integer :: i
    do i = 1, n
      x(i) = box * i / n
      v(i) = 0.0d0
    end do
  end subroutine initialize

  subroutine compute()
    integer :: i
    !$omp parallel do
    do i = 2, n-1
      f(i) = -k * (2.0d0*x(i) - x(i-1) - x(i+1))
    end do
    !$omp end parallel do
    f(1) = 0.0d0
    f(n) = 0.0d0
  end subroutine compute

  subroutine verlet()
    integer :: i
    !$omp parallel do
    do i = 1, n
      x(i) = x(i) + v(i)*dt + 0.5d0*f(i)*dt*dt/mass
      v(i) = v(i) + 0.5d0*f(i)*dt/mass
    end do
    !$omp end parallel do
    call compute()
    !$omp parallel do
    do i = 1, n
      v(i) = v(i) + 0.5d0*f(i)*dt/mass
    end do
    !$omp end parallel do
  end subroutine verlet

  subroutine print_results(step)
    integer, intent(in) :: step
    integer :: i
    if (mod(step,100)==0) then
      print *, 'Step:', step
      do i = 1, 5
        print *, 'Particle', i, ': x =', x(i), ', v =', v(i)
      end do
    end if
  end subroutine print_results

end module integration_md
