#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

// Declare the functions from prime_utils.c
int is_prime(int num);
int count_primes(int start, int end);

int main(int argc, char **argv) {
    int rank, size, limit;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) {
        if (argc != 2) {
            fprintf(stderr, "Usage: %s <upper_limit>\n", argv[0]);
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        limit = atoi(argv[1]);
        if (limit < 2) {
            fprintf(stderr, "Please enter an integer >= 2.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
    }

    // Broadcast limit to all processes
    MPI_Bcast(&limit, 1, MPI_INT, 0, MPI_COMM_WORLD);
    double t_start = MPI_Wtime();

    int range_size = limit / size;
    int start = rank * range_size + 1;
    int end = (rank == size - 1) ? limit : start + range_size - 1;

    int local_count = count_primes(start, end);

    int total_count = 0;
    MPI_Reduce(&local_count, &total_count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    double t_end = MPI_Wtime();
    if (rank == 0) {
        printf("Total prime numbers up to %d: %d\n", limit, total_count);
        printf("Execution time with %d processes: %.6f seconds\n", size, t_end - t_start);
    }

    MPI_Finalize();
    return 0;
}
