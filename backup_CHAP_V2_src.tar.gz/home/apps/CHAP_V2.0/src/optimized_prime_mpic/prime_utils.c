#include <stdio.h>

// Function to check if a number is prime
int is_prime(int num) {
    int i;
    if (num < 2) return 0;
    for (i = 2; i * i <= num; i++) {
        if (num % i == 0) return 0;
    }
    return 1;
}

// Function to count prime numbers in a range
int count_primes(int start, int end) {
    int i, count = 0;
    for (i = start; i <= end; i++) {
        if (is_prime(i)) count++;
    }
    return count;
}
