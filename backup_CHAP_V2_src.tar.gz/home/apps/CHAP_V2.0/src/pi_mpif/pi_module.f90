module pi_module
  implicit none
contains

  subroutine compute_pi(n, rank, size, local_sum)
    integer, intent(in) :: n, rank, size
    real(8), intent(out) :: local_sum
    real(8) :: h, x
    integer :: i

    h = 1.0d0 / n
    local_sum = 0.0d0

    ! Each process works on a subset of intervals
    do i = rank + 1, n, size
       x = (i - 0.5d0) * h
       local_sum = local_sum + 4.0d0 / (1.0d0 + x*x)
    end do

    ! Scale with step size applied later in main
  end subroutine compute_pi

end module pi_module
