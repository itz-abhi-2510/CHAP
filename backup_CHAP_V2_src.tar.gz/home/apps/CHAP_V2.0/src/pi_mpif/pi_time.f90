module timer_module
  use mpi
  implicit none
contains
  function get_time() result(t)
    real(8) :: t
    t = MPI_Wtime()
  end function get_time
end module timer_module
