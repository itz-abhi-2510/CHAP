program main
  use mpi
  use pi_module
  use timer_module
  implicit none

  integer :: ierr, rank, size, n
  real(8) :: local_sum, global_sum, pi
  real(8) :: start_time, end_time

  ! Initialize MPI
  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, size, ierr)

  ! Input intervals (only rank 0 reads)
  if (rank == 0) then
     print *, "Enter number of intervals (e.g., 100000000):"
     read(*,*) n
  end if

  ! Broadcast n
  call MPI_Bcast(n, 1, MPI_INTEGER, 0, MPI_COMM_WORLD, ierr)

  ! Start timer (only on rank 0)
  if (rank == 0) start_time = get_time()

  ! Compute partial sum
  call compute_pi(n, rank, size, local_sum)

  ! Reduce to get total sum
  call MPI_Reduce(local_sum, global_sum, 1, MPI_DOUBLE_PRECISION, MPI_SUM, 0, MPI_COMM_WORLD, ierr)

  ! Final result on rank 0
  if (rank == 0) then
     pi = (1.0d0 / n) * global_sum
     end_time = get_time()
     print *, "====================================="
     print *, "Calculated value of Pi = ", pi
     print *, "Execution Time (seconds) = ", end_time - start_time
     print *, "====================================="
  end if

  call MPI_Finalize(ierr)
end program main
