subroutine print_info(num_procs, ma, na, mb, nb)
  implicit none
  integer, intent(in) :: num_procs, ma, na, mb, nb

  write(*,*) ' '
  write(*,*) 'MATMAT - FORTRAN90 version'
  write(*,*) '  An MPI example to compute matrix product C = A * B.'
  write(*,'(a,i8)') '  Number of processes         = ', num_procs
  write(*,'(a,i8)') '  Number of rows of matrix A  = ', ma
  write(*,'(a,i8)') '  Number of columns of A      = ', na
  write(*,'(a,i8)') '  Number of rows of matrix B  = ', mb
  write(*,'(a,i8)') '  Number of columns of B      = ', nb
end subroutine print_info

subroutine print_matrix(title, c)
  implicit none
  character(len=*), intent(in) :: title
  real, intent(in) :: c(:,:)
  integer :: i

  write(*,*) ' '
  write(*,*) 'MATMAT - Master process:'
  write(*,*) '  ', trim(title)
  write(*,*) ' '
  do i = 1, min(5, size(c,1))
    write(*,'(5g14.6)') c(i,1:min(5, size(c,2)))
  end do
end subroutine print_matrix
