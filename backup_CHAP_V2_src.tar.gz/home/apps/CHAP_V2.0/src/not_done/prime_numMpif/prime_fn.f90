logical function is_prime(n)
    implicit none
    integer, intent(in) :: n
    integer :: j

    if (n <= 1) then
        is_prime = .false.
        return
    end if

    if (n == 2) then
        is_prime = .true.
        return
    end if

    if (mod(n, 2) == 0) then
        is_prime = .false.
        return
    end if

    do j = 3, int(sqrt(real(n))), 2
        if (mod(n, j) == 0) then
            is_prime = .false.
            return
        end if
    end do

    is_prime = .true.
end function is_prime
