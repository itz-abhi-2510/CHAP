subroutine compute_range(rank, size, N, start_num, end_num)
    implicit none
    integer, intent(in) :: rank, size, N
    integer, intent(out) :: start_num, end_num
    integer :: chunk_size

    chunk_size = (N - 1) / size   ! numbers from 2 to N

    start_num = rank * chunk_size + 2
    end_num   = start_num + chunk_size - 1

    ! Handle leftovers for last process
    if (rank == size - 1) end_num = N
end subroutine compute_range
