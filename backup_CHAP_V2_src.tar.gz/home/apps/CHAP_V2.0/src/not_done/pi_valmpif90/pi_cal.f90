module pi_calculator
    use mpi
    implicit none
contains
    function compute_pi(numprocs, rank) result(pi)
        integer, intent(in) :: numprocs, rank
        integer :: i, n, ierr
        integer(kind=8) :: local_count, global_count
        double precision :: x, y, pi
        integer, parameter :: num_samples = 10000

        n = num_samples / numprocs
        local_count = 0

        do i = 1, n
            call random_number(x)
            call random_number(y)
            if (x*x + y*y <= 1.0d0) then
                local_count = local_count + 1
            end if
        end do

        call MPI_Reduce(local_count, global_count, 1, MPI_INTEGER8, MPI_SUM, 0, MPI_COMM_WORLD, ierr)

        if (rank == 0) then
            pi = 4.0d0 * global_count / num_samples
        else
            pi = 0.0d0
        end if
    end function compute_pi
end module pi_calculator 
