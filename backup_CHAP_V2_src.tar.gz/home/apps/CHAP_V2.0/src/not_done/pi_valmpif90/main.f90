program mpi_pi                                
    use mpi
    use pi_calculator
    implicit none
    integer :: numprocs, rank, ierr
    double precision :: pi, start_time, end_time
    
    call MPI_Init(ierr)
    call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierr)
    call MPI_Comm_size(MPI_COMM_WORLD, numprocs, ierr)
    
    call MPI_Barrier(MPI_COMM_WORLD, ierr)
    start_time = MPI_Wtime()

    pi = compute_pi(numprocs, rank)
    
    if (rank == 0) then
        end_time = MPI_Wtime()
        print *, 'Estimated value of Pi: ', pi
        print *, 'Total execution time: ', end_time - start_time, 'seconds'
    end if

    call MPI_Finalize(ierr)
end program mpi_pi
