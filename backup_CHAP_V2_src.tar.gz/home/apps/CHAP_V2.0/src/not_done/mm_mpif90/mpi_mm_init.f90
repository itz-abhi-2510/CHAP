module matrix_init
  implicit none
contains
  subroutine init_matrix(n, A, B)
    integer, intent(in) :: n
    real, dimension(n, n), intent(out) :: A, B
    integer :: i, j

    ! Initialize matrix A and B with values
    do i = 1, n
      do j = 1, n
        A(i, j) = real(i * j, kind=8)  ! Arbitrary initialization
        B(i, j) = real(i + j, kind=8)  ! Arbitrary initialization
      end do
    end do
  end subroutine init_matrix
end module matrix_init

