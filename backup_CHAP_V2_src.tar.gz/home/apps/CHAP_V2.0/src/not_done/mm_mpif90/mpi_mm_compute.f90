module matrix_multiply
  use mpi
  implicit none
contains
  subroutine multiply_matrices(n, A, B, C)
    integer, intent(in) :: n
    real, dimension(n, n), intent(in) :: A, B
    real, dimension(n, n), intent(out) :: C
    integer :: i, j, k, rank, size, ierr
    real, dimension(n, n) :: local_A, local_C
    integer :: rows_per_proc, start_row, end_row

    ! Get the rank and size of the MPI process
    call MPI_COMM_RANK(MPI_COMM_WORLD, rank, ierr)
    call MPI_COMM_SIZE(MPI_COMM_WORLD, size, ierr)

    ! Calculate the number of rows each process will handle
    rows_per_proc = n / size
    start_row = rank * rows_per_proc + 1
    end_row = (rank + 1) * rows_per_proc

    ! Scatter matrix A and matrix B to all processes
    call MPI_Scatter(A(start_row, :), rows_per_proc * n, MPI_REAL, &
                     local_A, rows_per_proc * n, MPI_REAL, 0, MPI_COMM_WORLD, ierr)
    call MPI_Bcast(B, n * n, MPI_REAL, 0, MPI_COMM_WORLD, ierr)

    ! Perform local matrix multiplication
    local_C = 0.0
    do i = 1, rows_per_proc
      do j = 1, n
        do k = 1, n
          local_C(i, j) = local_C(i, j) + local_A(i, k) * B(k, j)
        end do
      end do
    end do

    ! Gather the results from all processes
     call MPI_Gather(local_C, rows_per_proc * n, MPI_REAL, C(start_row, :), rows_per_proc * n, MPI_REAL, 0, MPI_COMM_WORLD, ierr)
  end subroutine multiply_matrices
end module matrix_multiply

