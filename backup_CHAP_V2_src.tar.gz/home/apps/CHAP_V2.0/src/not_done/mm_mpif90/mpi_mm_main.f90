program matrix_multiplication
  use mpi
  use matrix_init
  use matrix_multiply
  implicit none
  integer, parameter :: n = 100
  real, dimension(n, n) :: A, B, C
  integer :: ierr, rank, size
  real :: start_time, end_time, total_time

  ! Initialize MPI
  call MPI_INIT(ierr)
  call MPI_COMM_RANK(MPI_COMM_WORLD, rank, ierr)
  call MPI_COMM_SIZE(MPI_COMM_WORLD, size, ierr)

  ! Record the start time
  call cpu_time(start_time)

  ! Initialize matrices A and B on rank 0
  if (rank == 0) then
    call init_matrix(n, A, B)
  end if

  ! Perform matrix multiplication: C = A * B
  call multiply_matrices(n, A, B, C)

  ! Record the end time
  call cpu_time(end_time)

  ! Calculate total execution time
  total_time = end_time - start_time

  ! Root process prints the total execution time
  if (rank == 0) then
    print *, 'Total execution time: ', total_time, ' seconds.'
    ! Uncomment to print part of the result (optional)
    ! print *, C(1, 1), C(1, 2), C(2, 1)
  end if

  ! Finalize MPI
  call MPI_FINALIZE(ierr)

end program matrix_multiplication

