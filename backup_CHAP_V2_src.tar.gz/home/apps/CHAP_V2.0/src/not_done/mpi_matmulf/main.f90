program main
  use mpi
  use mpi_utils
  use matrix_ops
  use timestamp_mod

  implicit none
  integer :: ierr, id, num_procs

  call MPI_Init(ierr)
  call MPI_Comm_rank(MPI_COMM_WORLD, id, ierr)
  call MPI_Comm_size(MPI_COMM_WORLD, num_procs, ierr)

  call run_matrix_multiplication(id, num_procs)

  call MPI_Finalize(ierr)

  if (id == 0) then
    call timestamp()
    print *, 'MATMAT: Normal end of execution.'
  end if
end program main
