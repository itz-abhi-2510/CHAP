module matrix_ops
  use mpi
  implicit none
  integer, parameter :: ma = 10, na = 20, mb = 20, nb = 25
  real, allocatable :: a(:,:), b(:,:), c(:,:)
contains
  subroutine run_matrix_multiplication(id, num_procs)
    integer, intent(in) :: id, num_procs
    allocate(a(ma, na), b(mb, nb), c(ma, nb))
    if (id == 0) then
      call initialize_matrices()
      print *, 'Matrices initialized on process 0'
    end if
    call MPI_Bcast(a, ma * na, MPI_REAL, 0, MPI_COMM_WORLD, ierr)
    call compute_matrix_product(id, num_procs)
    deallocate(a, b, c)
  end subroutine run_matrix_multiplication

  subroutine initialize_matrices()
    integer :: i, j
    do i = 1, ma
      do j = 1, na
        a(i, j) = real(mod(i + j, 5))
      end do
    end do
    do i = 1, mb
      do j = 1, nb
        b(i, j) = real(mod(i * j, 5))
      end do
    end do
  end subroutine initialize_matrices

  subroutine compute_matrix_product(id, num_procs)
    integer, intent(in) :: id, num_procs
    integer :: i, j
    if (id == 0) then
      c = matmul(a, b)
      print *, 'Matrix multiplication completed on process 0'
    end if
  end subroutine compute_matrix_product
end module matrix_ops
