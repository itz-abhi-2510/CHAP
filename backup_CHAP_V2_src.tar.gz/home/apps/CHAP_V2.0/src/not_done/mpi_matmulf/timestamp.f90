module timestamp_mod
  implicit none
contains
  subroutine timestamp()
    print *, 'Timestamp function executed.'
  end subroutine timestamp
end module timestamp_mod
