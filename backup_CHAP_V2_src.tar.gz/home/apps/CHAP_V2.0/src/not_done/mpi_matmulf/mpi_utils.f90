module mpi_utils
  use mpi
  implicit none
contains
  subroutine initialize_mpi(id, num_procs)
    integer, intent(out) :: id, num_procs
    integer :: ierr
    call MPI_Comm_rank(MPI_COMM_WORLD, id, ierr)
    call MPI_Comm_size(MPI_COMM_WORLD, num_procs, ierr)
  end subroutine initialize_mpi
end module mpi_utils
