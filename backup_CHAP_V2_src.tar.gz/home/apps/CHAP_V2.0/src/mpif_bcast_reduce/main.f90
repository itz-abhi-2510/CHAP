program main
    use, intrinsic :: iso_fortran_env, only: int32, real64
    use mpi_f08
    use mod_func
    implicit none

    integer(int32) :: i, ierror, master, p
    integer(int32) :: num_proc, rank, n, my_n
    integer(int32) :: source, destin, tag
    real(real64) :: a, b, my_a, my_b
    real(real64) :: error, total, wtime, x, my_total, exact
    type(MPI_Status) :: mpistatus

    a = 1.0_real64
    b = 10.0_real64
    n = huge(1_int32)
    exact = f1_exact
    master = 0

    call MPI_Init(ierror)
    call MPI_Comm_size(MPI_COMM_WORLD, num_proc, ierror)
    call MPI_Comm_rank(MPI_COMM_WORLD, rank, ierror)

    if (rank == master) then
        my_n = n / (num_proc - 1)
        n = (num_proc - 1) * my_n
        wtime = MPI_Wtime()

        write (*,*) ''
        write (*,*) '  Quadrature of f(x) from A to B.'
        write (*,*) '  f(x) = log(pi*x)*sin(pi*x)**2 + x'
        write (*,'(a,g14.6)') '  A        = ', a
        write (*,'(a,g14.6)') '  B        = ', b
        write (*,'(a,i12)') '  N        = ', n
        write (*,'(a,g24.16)') '  Exact    = ', exact
        write (*,*) ''
    end if

    call MPI_Bcast(my_n, 1, MPI_INTEGER, master, MPI_COMM_WORLD, ierror)

    if (rank == master) then
        do p = 1, num_proc - 1
            my_a = (real(num_proc - p, kind=real64)*a + real(p - 1, kind=real64)*b) &
                     / real(num_proc - 1, kind=real64)
            my_b = (real(num_proc - p - 1, kind=real64)*a + real(p, kind=real64)*b) &
                     / real(num_proc - 1, kind=real64)

            call MPI_Send(my_a, 1, MPI_DOUBLE_PRECISION, p, 1, MPI_COMM_WORLD, ierror)
            call MPI_Send(my_b, 1, MPI_DOUBLE_PRECISION, p, 2, MPI_COMM_WORLD, ierror)
        end do
        total = 0.0_real64
        my_total = 0.0_real64
    else
        call MPI_Recv(my_a, 1, MPI_DOUBLE_PRECISION, master, 1, MPI_COMM_WORLD, mpistatus, ierror)
        call MPI_Recv(my_b, 1, MPI_DOUBLE_PRECISION, master, 2, MPI_COMM_WORLD, mpistatus, ierror)

        my_total = 0.0_real64
        do i = 1, my_n
            x = (real(my_n - i, kind=real64)*my_a + real(i - 1, kind=real64)*my_b) &
                 / real(my_n - 1, kind=real64)
            my_total = my_total + f1(x)
        end do
        my_total = (my_b - my_a) * my_total / real(my_n, kind=real64)
        write (*,'(a,i3,a,g14.6)') '  RANK: ', rank, ' Partial Quadrature: ', my_total
    end if

    call MPI_Reduce(my_total, total, 1, MPI_DOUBLE_PRECISION, MPI_SUM, master, MPI_COMM_WORLD, ierror)

    if (rank == master) then
        error = abs(total - exact)
        wtime = MPI_Wtime() - wtime
        write (*,'(a,g24.16)') '  Estimate = ', total
        write (*,'(a,g14.6)') '  Error    = ', error
        write (*,'(a,g14.6)') '  Time     = ', wtime
        write (*,*) ''
        write (*,*) '  Normal end of execution.'
    end if

    call MPI_Finalize(ierror)

end program main
