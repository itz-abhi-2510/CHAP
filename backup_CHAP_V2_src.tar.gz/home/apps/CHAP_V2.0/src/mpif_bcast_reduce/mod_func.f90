module mod_func
    use, intrinsic :: iso_fortran_env, only: real64
    implicit none

    real(real64), parameter :: f1_exact = real(61.675091159487667993149630, kind=real64)
    real(real64), parameter :: pi = real(3.141592653589793238462643, kind=real64)

contains

    function f1(x) result(val)
        real(real64), intent(in) :: x
        real(real64) :: val

        val = log(pi*x)*sin(pi*x)**2 + x
    end function f1

    function f2(x) result(val)
        real(real64), intent(in) :: x
        real(real64) :: val

        val = 50.0_real64 / (pi * (2500.0_real64 * x * x + 1.0_real64))
    end function f2

end module mod_func
