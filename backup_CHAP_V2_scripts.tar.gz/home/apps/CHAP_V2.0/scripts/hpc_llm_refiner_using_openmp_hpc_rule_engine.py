#!/usr/bin/env python3

import json
import argparse
import subprocess
import glob
import os

# -------------------------------------------------
# CONFIGURATION (EDIT ONCE)
# -------------------------------------------------

LLAMA_BIN = "/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"
MODEL_PATH = "/home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf"

# -------------------------------------------------
# Rule Engine
# -------------------------------------------------

def deduplicate_hotspots(hotspots):
    unique = {}
    for h in hotspots:
        func = h["function"]
        if func not in unique or h["time_percent"] > unique[func]["time_percent"]:
            unique[func] = h
    return list(unique.values())


def generate_rules(summary):
    suggestions = []

    omp = summary.get("openmp", {})
    worker = omp.get("worker_time_percent", 0)

    if worker > 90:
        suggestions.append(
            "OpenMP worker threads dominate runtime (>90%). "
            "This indicates possible oversubscription or load imbalance. "
            "Reduce OMP_NUM_THREADS and tune scheduling."
        )

    hotspots = deduplicate_hotspots(summary.get("hotspots", []))

    for h in hotspots:
        func = h["function"]

        # Filter TAU/OpenMP internals
        if (
            "OpenMP_Thread_Type" in func
            or "ompt_thread_worker" in func
            or func.startswith(".TAU")
        ):
            continue

        if h["time_percent"] > 50:
            suggestions.append(
                f"Function '{func}' dominates runtime "
                f"({h['time_percent']}%). Prioritize optimization here."
            )

    if not suggestions:
        suggestions.append(
            "No dominant bottlenecks detected. Perform scaling, affinity, and compiler optimization studies."
        )

    return suggestions

def refine_with_llama(rules):
    prompt = f"""
You are an HPC performance expert.

Below are rule-based performance findings derived from TAU profiling.
Do NOT introduce new issues.
Do NOT speculate.

Guidelines:
- Refine and shorten the suggestions
- Keep them performance-focused (OpenMP, MPI, memory, vectorization)
- Maximum 5 bullet points

Rule-based suggestions:
{chr(10).join('- ' + r for r in rules)}

Final refined suggestions:
"""

    cmd = [
        LLAMA_BIN,
        "-m", MODEL_PATH,
        "-p", prompt,
        "--n-predict", "250",
        "--temp", "0.2",
        "--no-display-prompt"
    ]

    # Python 3.6 compatible subprocess
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

    if result.returncode != 0:
        print("[ERROR] llama.cpp execution failed")
        print(result.stderr)
        return None

    return result.stdout.strip()



# -------------------------------------------------
# Main
# -------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate HPC optimization suggestions from all select_* directories"
    )
    parser.add_argument(
        "-i", "--input-dir",
        required=True,
        help="Base directory containing select_* folders"
    )

    args = parser.parse_args()

    select_dirs = sorted(
        d for d in glob.glob(os.path.join(args.input_dir, "select_*"))
        if os.path.isdir(d)
    )

    if not select_dirs:
        raise ValueError("No select_* directories found")

    for sel in select_dirs:
        summary_file = os.path.join(sel, "tau_summary.json")

        if not os.path.isfile(summary_file):
            print(f"[SKIP] tau_summary.json not found in {sel}")
            continue

        with open(summary_file) as f:
            summary = json.load(f)

        rules = generate_rules(summary)
        refined = refine_with_llama(rules)

        out_file = os.path.join(sel, "llm_suggestions.txt")
        with open(out_file, "w") as f:
            f.write(refined or "LLM failed")

        print(f"[OK] Suggestions written to: {out_file}")

if __name__ == "__main__":
    main()
