import json
import subprocess
import argparse
from pathlib import Path

# ------------------------------
# CONFIG (edit once)
# ------------------------------
LLAMA_BIN = "/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"
MODEL_PATH = "/home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf"

# ------------------------------
# LLM refinement
# ------------------------------
def refine_with_llama(mpi_rules):
    prompt = f"""
You are an HPC performance expert.

Below are FACTUAL MPI performance findings derived from TAU profiling.
Do NOT introduce new issues.
Do NOT speculate.
Do NOT repeat points.

Instructions:
- Focus ONLY on MPI performance
- Keep suggestions actionable
- Maximum 5 bullet points
- No explanations, only recommendations

MPI rule-based findings:
{chr(10).join('- ' + r for r in mpi_rules)}

Final refined MPI optimization suggestions:
"""

    cmd = [
        LLAMA_BIN,
        "-m", MODEL_PATH,
        "-p", prompt,
        "--n-predict", "200",
        "--temp", "0.2",
        "--no-display-prompt"
    ]

    # Python 3.6 compatible
    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True
    )

    if result.returncode != 0:
        print("[ERROR] llama.cpp execution failed")
        print(result.stderr)
        return None

    return result.stdout.strip()


# ------------------------------
# Main (CLI)
# ------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="MPI LLM Refiner using llama.cpp"
    )
    parser.add_argument(
        "-i", "--input",
        required=True,
        help="MPI rule-engine output JSON file"
    )
    parser.add_argument(
        "-o", "--output",
        required=True,
        help="Output file for refined MPI suggestions"
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    with open(input_path) as f:
        data = json.load(f)

    mpi_rules = data.get("suggestions", [])

    if not mpi_rules:
        print("No MPI issues detected. Skipping LLM refinement.")
        return

    refined = refine_with_llama(mpi_rules)

    if refined is None:
        return

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        f.write(refined)

    print("\n=== Refined MPI Optimization Suggestions ===\n")
    print(refined)
    print(f"\nSaved to: {output_path}")


if __name__ == "__main__":
    main()

