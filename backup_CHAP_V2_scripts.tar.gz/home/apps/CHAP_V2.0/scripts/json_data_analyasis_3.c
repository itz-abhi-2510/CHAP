#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define CRITICAL_THRESHOLD 0.5
#define MODERATE_THRESHOLD 0.01

// Simplify to just the function name (e.g., from "main => MPI_Init() C [{file}]" to "MPI_Init")
void simplify_function_name(char *function) {
    // Step 1: keep only after last =>
    char *arrow = strrchr(function, '>');
    if (arrow && *(arrow + 1) == ' ') {
        memmove(function, arrow + 2, strlen(arrow + 2) + 1);
    }

    // Step 2: remove source info like " C [{file.c} ...]"
    char *meta = strstr(function, " C [{");
    if (meta) *meta = '\0';

    // Step 3: trim trailing space
    size_t len = strlen(function);
    while (len > 0 && (function[len - 1] == ' ' || function[len - 1] == '\n')) {
        function[--len] = '\0';
    }
}

// Check if function has already been reported
int already_reported(char *func, char reported[][512], int count) {
    for (int i = 0; i < count; i++) {
        if (strcmp(func, reported[i]) == 0)
            return 1;
    }
    return 0;
}

void analyze_json(const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    rewind(file);

    char *data = malloc(length + 1);
    fread(data, 1, length, file);
    data[length] = '\0';
    fclose(file);

    cJSON *root = cJSON_Parse(data);
    free(data);
    if (!root) {
        printf("Error parsing JSON file\n");
        return;
    }

    char reported[1024][512];
    int report_count = 0;

    printf("\n==== Optimization Suggestions ====\n");

    int total = cJSON_GetArraySize(root);
    for (int i = 0; i < total; i++) {
        cJSON *item = cJSON_GetArrayItem(root, i);
        cJSON *func = cJSON_GetObjectItem(item, "function");
        cJSON *secs = cJSON_GetObjectItem(item, "excl_secs");
        if (!func || !secs) continue;

        char function[512];
        strncpy(function, func->valuestring, 511);
        function[511] = '\0';
        simplify_function_name(function);

        if (already_reported(function, reported, report_count)) continue;
        strcpy(reported[report_count++], function);

        double time = atof(secs->valuestring);

        if (time >= CRITICAL_THRESHOLD) {
            printf("[CRITICAL] %s – %.3fs. Optimize or parallelize.\n", function, time);
        } else if (time >= MODERATE_THRESHOLD) {
            printf("[MODERATE] %s – %.3fs. Review efficiency.\n", function, time);
        } else {
            printf("[OK] %s – %.3fs.\n", function, time);
        }
    }

    cJSON_Delete(root);
}

int main() {
    char filename[256];
    printf("Enter the path to the JSON profiling data file: ");
    if (scanf("%255s", filename) != 1) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }

    analyze_json(filename);
    return 0;
}
