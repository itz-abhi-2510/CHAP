#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define CRITICAL_THRESHOLD 0.5
#define MODERATE_THRESHOLD 0.01

void simplify_function_name(char *function) {
    char *arrow = strstr(function, "=>");
    if (arrow) {
        // Use only the part after last arrow
        char *last = strrchr(function, '>');
        if (last && *(last + 1) == ' ') {
            memmove(function, last + 2, strlen(last + 2) + 1);
        }
    }
    // Optional: strip source file info
    char *brace = strchr(function, '[');
    if (brace) *brace = '\0';
}

int already_reported(char *func, char reported[][512], int count) {
    for (int i = 0; i < count; i++) {
        if (strcmp(func, reported[i]) == 0)
            return 1;
    }
    return 0;
}

void analyze_json(const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("File open error");
        return;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    rewind(file);

    char *data = malloc(length + 1);
    fread(data, 1, length, file);
    data[length] = '\0';
    fclose(file);

    cJSON *root = cJSON_Parse(data);
    free(data);
    if (!root) {
        printf("JSON parse error\n");
        return;
    }

    char reported[1024][512];
    int report_count = 0;

    printf("\n==== Optimization Suggestions ====\n");

    int total = cJSON_GetArraySize(root);
    for (int i = 0; i < total; i++) {
        cJSON *item = cJSON_GetArrayItem(root, i);
        cJSON *func = cJSON_GetObjectItem(item, "function");
        cJSON *secs = cJSON_GetObjectItem(item, "excl_secs");
        if (!func || !secs) continue;

        char function[512];
        strncpy(function, func->valuestring, 511);
        function[511] = '\0';
        simplify_function_name(function);

        if (already_reported(function, reported, report_count)) continue;
        strcpy(reported[report_count++], function);

        double time = atof(secs->valuestring);

        if (time >= CRITICAL_THRESHOLD) {
            printf("[CRITICAL] %s – %.3fs. Optimize or parallelize.\n", function, time);
        } else if (time >= MODERATE_THRESHOLD) {
            printf("[MODERATE] %s – %.3fs. Review efficiency.\n", function, time);
        } else {
            printf("[OK] %s – %.3fs.\n", function, time);
        }
    }

    cJSON_Delete(root);
}
int main() {
    char filename[256];
    printf("Enter the path to the JSON profiling data file: ");
    if (scanf("%255s", filename) != 1) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }

    analyze_json(filename);
    return 0;
}

