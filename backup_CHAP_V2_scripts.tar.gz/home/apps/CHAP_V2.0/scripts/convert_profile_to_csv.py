import csv

# Input and output file paths
#input_file = "result_oss.txt"
input_file="profile.txt"
#input_file = input("Enter the input file name(with extension):").strip() 
output_file = "profile.csv"

# Initialize variables
sections = []
current_section = None

# Parse the input file
with open(input_file, "r") as file:
    for line in file:
        line = line.strip()
        if line.startswith("Thread:"):  # Detect a new thread section
            current_section = line.replace("Thread:", "").strip()
            sections.append({"thread": current_section, "data": []})
        elif line and not line.startswith("-") and not line.startswith("excl.secs"):  # Data line
            if current_section:
                sections[-1]["data"].append(line)

# Write to CSV
with open(output_file, "w", newline="") as csvfile:
    csvwriter = csv.writer(csvfile)
    # Write header
    csvwriter.writerow(["Thread", "excl_secs", "excl_percent", "cum_percent", "calls", "function"])

    # Process and write each section
    for section in sections:
        thread = section["thread"]
        for entry in section["data"]:
            parts = entry.split()
            excl_secs = parts[0]
            excl_percent = parts[1]
            cum_percent = parts[2]
            calls = parts[3]
            function = " ".join(parts[4:])  # Rest is function name
            csvwriter.writerow([thread, excl_secs, excl_percent, cum_percent, calls, function])

print(f"Data successfully converted to CSV format in {output_file}")

