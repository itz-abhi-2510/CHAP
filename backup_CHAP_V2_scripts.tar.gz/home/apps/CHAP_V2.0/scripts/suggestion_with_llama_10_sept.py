import os
from llama_cpp import Llama

def load_model(model_path):
    """Load the GGUF model with llama-cpp-python"""
    return Llama(model_path=model_path, n_ctx=4096)

def read_profiling_data(profile_dir):
    """Read all profiling text files from the directory"""
    profiling_data = ""
    for root, _, files in os.walk(profile_dir):
        for file in files:
            if file.endswith(".txt"):  # assuming profiling data stored as .txt
                with open(os.path.join(root, file), "r") as f:
                    profiling_data += f"\n--- {file} ---\n"
                    profiling_data += f.read()
    return profiling_data

def generate_suggestions(llm, profiling_text):
    """Ask the model to analyze and suggest optimizations"""
    prompt = f"""
You are an HPC optimization assistant. 
The following is profiling data from an application run. 
Identify hotspots, bottlenecks, and provide **short, actionable suggestions** 
for improving performance (e.g., loop optimizations, memory usage, MPI/OpenMP tuning).

Profiling Data:
{profiling_text}

Now provide suggestions:
"""
    output = llm(prompt, max_tokens=512, temperature=0.7)
    return output["choices"][0]["text"]

if __name__ == "__main__":
    # Ask user for profiling directory
    profile_dir = input("Enter the path to your profiling directory: ").strip()

    # Path to your GGUF model
    model_path = "/home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf"

    print("Loading model... (this may take a while)")
    llm = load_model(model_path)

    print("Reading profiling data...")
    profiling_text = read_profiling_data(profile_dir)

    print("Generating optimization suggestions...\n")
    suggestions = generate_suggestions(llm, profiling_text)

    print("=== Optimization Suggestions ===")
    print(suggestions)

