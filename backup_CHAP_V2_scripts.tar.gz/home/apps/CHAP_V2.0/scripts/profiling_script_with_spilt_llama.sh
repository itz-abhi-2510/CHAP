#!/bin/bash

# ============================================================
# HPC Profiling Automation + Nodewise Suggestions Generator
# ============================================================

# Get timestamp
timestamp=$(date '+%d_%m_%Y-%H_%M-%S')

# Validate TAU_MAKEFILE
if [ -z "$TAU_MAKEFILE" ]; then
    echo "Error: TAU_MAKEFILE is not set. Please source TAU setup."
    exit 1
fi

echo "Choose the application category:"
echo "1. C Applications"
echo "2. Fortran Applications"
read -p "Enter the number corresponding to the category: " app_category

if [[ "$app_category" -eq 1 ]]; then
    echo "Choose the C-based application type:"
    echo "1. OpenMP using C"
    echo "2. MPI using C"
    echo "3. Hybrid (OpenMP + MPI) using C"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_cc.sh"
elif [[ "$app_category" -eq 2 ]]; then
    echo "Choose the Fortran-based application type:"
    echo "1. OpenMP using Fortran"
    echo "2. MPI using Fortran"
    echo "3. Hybrid (OpenMP + MPI) using Fortran"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_f90.sh"
else
    echo "Invalid selection. Exiting."
    exit 1
fi

# ===============================
# Locate select.tau files
# ===============================
function find_select_tau_files {
    read -p "Enter the directory path containing select.tau files: " tau_dir
    if [ ! -d "$tau_dir" ]; then
        echo "Error: Directory does not exist: $tau_dir"
        exit 1
    fi
    select_tau_files=$(ls -1 "$tau_dir"/select*.tau 2>/dev/null)
    if [ -z "$select_tau_files" ]; then
        echo "Error: No select.tau files found in $tau_dir"
        exit 1
    fi
    echo -e "\nFound select.tau files: $select_tau_files"
}
find_select_tau_files

# ===============================
# Source file directory
# ===============================
read -p "Enter the directory path containing source files: " source_dir
if [ ! -d "$source_dir" ]; then
    echo "Error: Directory does not exist: $source_dir"
    exit 1
fi
source_files=$(find "$source_dir" -type f \( -iname "*.c" -o -iname "*.f90" \))
if [ -z "$source_files" ]; then
    echo "Error: No source files found in $source_dir"
    exit 1
fi
echo -e "\nFound source files: $source_files"

first_source_file=$(echo "$source_files" | head -n 1)
binary_file=$(basename "$first_source_file" | sed 's/\.[^.]*$//')
echo "Binary file will be: $binary_file"

# MPI process count
read -p "Enter the number of processes for execution: " num_procs

# Main output directory
main_output_dir="/home/apps/CHAP_V2.0/result/${binary_file}_${timestamp}"
mkdir -p "$main_output_dir"

# ===============================
# Process each select.tau
# ===============================
for select_tau_file in $select_tau_files; do
    echo "Processing: $select_tau_file"
    select_name=$(basename "$select_tau_file" .tau)
    loop_output_dir="$main_output_dir/$select_name"
    mkdir -p "$loop_output_dir"

    cp $source_files "$loop_output_dir/"
    cp "$select_tau_file" "$loop_output_dir/"
    cd "$loop_output_dir" || exit 1

    echo "Compiling sources..."
    if ! $tau_wrapper -optTauSelectFile="$select_name.tau" $source_files -o "$binary_file"; then
        echo "Error: Compilation failed."
        continue
    fi

    if ! mpirun -np "$num_procs" tau_exec -T openmpi -ebs ./$binary_file; then
        echo "Error: Execution failed."
        continue
    fi

    echo "Generating profiling data..."
    if ! pprof; then
        echo "Error: Profiling failed."
        continue
    fi
    paraprof --oss profile.* > "$loop_output_dir/profile.txt"

    # ===============================
    # Split nodewise
    # ===============================
    echo "Splitting profile.txt nodewise..."
    awk -v outdir="$loop_output_dir" '
    /^Thread: n,c,t/ {
        if (out != "") close(out)
        split($3, arr, ",")
        n=arr[1]; c=arr[2]; t=arr[3]
        out = sprintf("%s/node_%s_%s_%s.txt", outdir, n, c, t)
    }
    out != "" { print >> out }
    ' "$loop_output_dir/profile.txt"

    echo "Nodewise data stored in $loop_output_dir"

    python3 /home/apps/CHAP_V2.0/scripts/convert_profile_to_csv.py "$loop_output_dir/profile.csv"
    python3 /home/apps/CHAP_V2.0/scripts/convert_csv_to_json.py "$loop_output_dir/profile.json"

    # ===============================
    # Generate Suggestions with LLaMA
    # ===============================
    echo "Generating suggestions using llama.cpp..."
     #######./llama-cli    -m /home/apps/CHAP_V2.0/dependancy/llama_model/codellama-7b-instruct.Q4_K_M.gguf    -p "You are an HPC optimization assistant. Based on the profiling data below, write only short, actionable performance suggestions to optimize execution time and identify bottlenecks:\n\n$(cat $profile.txt)"    > sugg_codellama_q4.txt

     MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/codellama-7b-instruct.Q4_K_M.gguf"
     #MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/phind-codellama-34b-v2.Q2_K.gguf"
     
     #MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/all-hands_openhands-lm-32b-v0.1-Q5_K_M.gguf"
    # Ask user if they want to save suggestions to a file
    read -p "Do you also want to save suggestions into suggestions.txt? (y/n): " save_choice
    if [[ "$save_choice" =~ ^[Yy]$ ]]; then
        output_file="$loop_output_dir/suggestions.txt"
        > "$output_file"
        save_to_file=true
        echo "Suggestions will also be saved to $output_file"
    else
        save_to_file=false
    fi

    # Loop through nodewise split files
    for file in "$loop_output_dir"/node_*.txt; do
        if [ -f "$file" ]; then
            echo -e "\n=== Suggestions for $(basename "$file") ==="
            if $save_to_file; then
                echo "=== Suggestions for $(basename "$file") ===" >> "$output_file"
            fi
             
            ##### ./llama-cli -m /home/apps/CHAP_V2.0/dependancy/llama_model/phind-codellama-34b-v2.Q2_K.gguf -p "write a suggestions to  optimize this given application. $(cat profile.txt)" >  suggestions_02_09_2025_1.txt
       

#       ./llama-cli -m /  -p "You are an HPC optimization assistant. Based on the profiling data below, write only short, actionable performance suggestions to optimize execution time and identify bottlenecks:\n\n$(cat $profile.txt)"          
             
          
                     
            /home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli -m /home/apps/CHAP_V2.0/dependancy/llama_model/codellama-7b-instruct.Q4_K_M.gguf "$MODEL_PATH"           \
            -p "write a suggestions to  optimize this given application"           \
                -f "$file" | tee >(if $save_to_file; then cat >> "$output_file"; fi)

            echo -e "\n----------------------------------------"
            if $save_to_file; then echo -e "\n----------------------------------------" >> "$output_file"; fi
        fi
    done
done

echo "✅ All tasks completed. Results are in $main_output_dir"
