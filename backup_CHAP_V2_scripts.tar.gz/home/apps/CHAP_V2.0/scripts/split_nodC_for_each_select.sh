#!/bin/bash

base_dir="/home/apps/CHAP_V2.0/result/pi_ompc2_15_09_2025-15_18-58/"

# Loop through all select_x directories
for select_dir in "$base_dir"/select_*; do
    input="$select_dir/profile.txt"

    # Skip if profile.txt not found
    if [ ! -f "$input" ]; then
        echo "Skipping $select_dir (no profile.txt found)"
        continue
    fi

    echo "Processing $input ..."

    # Run awk to split into node-wise files in same directory
    awk -v outdir="$select_dir" '
    /^Thread: n,c,t/ {
        if (out != "") close(out)
        split($3, arr, ",")
        n=arr[1]
        c=arr[2]
        t=arr[3]
        out = sprintf("%s/node_%s_%s_%s.txt", outdir, n, c, t)
    }
    out != "" { print >> out }
    ' "$input"

    echo "Done → node-wise files saved in $select_dir"
done
