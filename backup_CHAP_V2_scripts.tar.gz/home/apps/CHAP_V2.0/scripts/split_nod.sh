#!/bin/bash

# Ask for input file path
read -p "Enter input file path (.txt): " input

# Check if file exists
if [ ! -f "$input" ]; then
    echo "Error: File '$input' not found!"
    exit 1
fi

# Ask for output directory
read -p "Enter output directory path: " outdir

# Create output directory if not exists
mkdir -p "$outdir"

# Run awk to split log file
awk -v outdir="$outdir" '
/^Thread: n,c,t/ {
    # Close previous file if open
    if (out != "") close(out)

    # Extract numbers n,c,t from 3rd field
    split($3, arr, ",")
    n=arr[1]
    c=arr[2]
    t=arr[3]

    # Prepare output file name inside given directory
    out = sprintf("%s/node_%s_%s_%s.txt", outdir, n, c, t)
}

# Write everything into the file
out != "" { print >> out }
' "$input"

echo "Data has been split and stored in: $outdir"
