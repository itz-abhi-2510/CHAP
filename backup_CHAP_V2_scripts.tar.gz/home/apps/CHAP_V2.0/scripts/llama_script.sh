#!/bin/bash
# ==========================================
# Script: profile_suggest.sh
# Usage : ./profile_suggest.sh <profiling_output_file>
# Output: suggestions.txt
# ==========================================

# ---- Configurable Variables ----
MODEL="/home/apps/CHAP_V2.0/dependancy/llama_model/all-hands_openhands-lm-32b-v0.1-Q5_K_M.gguf"  # Path to your GGUF model (e.g. all-hands_openhands-lm-32b-v0.1.Q5_K_M.gguf) 

LLAMA_BIN="./home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"        # Path to llama.cpp binary (could also be ./llama-cli)
OUTPUT="suggestions.txt"  # File where suggestions will be stored

# ---- Check Input ----
if [ $# -ne 1 ]; then
    echo "Usage: $0 <profiling_output_file>"
    exit 1
fi

INPUT_FILE="$1"

if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: File '$INPUT_FILE' not found!"
    exit 1
fi

# ---- Run Model ----
echo "Running model on profiling output..."
$LLAMA_BIN -m "$MODEL" \
  -n 512 \                          # max tokens to generate
  -p "You are an HPC optimization assistant. Analyze the following profiling output from C/Fortran applications and provide concise, actionable optimization suggestions.\n\n$(cat "$INPUT_FILE")\n\nSuggestions:" \
  > "$OUTPUT"

echo "Suggestions saved in $OUTPUT"
