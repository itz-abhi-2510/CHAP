#!/bin/bash

# -----------------------------------------------
# Script: generate_suggestions.sh
# Purpose: Analyze MPI/OpenMP C & Fortran source codes
#          using llama.cpp (Mistral-7B-Instruct model)
#          to generate performance optimization suggestions
#          without rewriting the source code.
# -----------------------------------------------

# Take source directory from user
read -p "Enter the path to the source code directory: " SRC_DIR
if [ ! -d "$SRC_DIR" ]; then
    echo "❌ Error: Source directory not found!"
    exit 1
fi

# Take output directory from user
read -p "Enter the output directory path: " OUT_DIR
mkdir -p "$OUT_DIR"

# Define llama model path (update if different)
MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf"

if [ ! -f "$MODEL_PATH" ]; then
    echo "❌ Error: Model file not found at $MODEL_PATH"
    exit 1
fi

# Find all supported source files
SOURCE_FILES=$(find "$SRC_DIR" -type f \( -name "*.c" -o -name "*.f90" -o -name "*.f" -o -name "*.for" \))

if [ -z "$SOURCE_FILES" ]; then
    echo "❌ No source files found in the given directory!"
    exit 1
fi

echo "🔍 Found source files:"
echo "$SOURCE_FILES"
echo

# Loop over each source file
for FILE in $SOURCE_FILES; do
    BASENAME=$(basename "$FILE")
    OUT_FILE="$OUT_DIR/${BASENAME}_suggestions.txt"

    echo "🧠 Analyzing performance of: $BASENAME ..."
    
    /home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli \
        -m "$MODEL_PATH" \
        -p "You are an HPC performance advisor. 
Analyze the following MPI/OpenMP source code written in C or Fortran.
Do NOT rewrite or modify the code.
Only provide a performance optimization report.

Focus strictly on:
- Identifying performance bottlenecks.
- Highlighting inefficient loops, synchronization, or communication.
- Memory/cache utilization inefficiencies.
- Parallel imbalance and thread scalability.
- Recommendations for compiler flags or restructuring to optimize runtime.

Now analyze this code:
--------------------------
$(cat "$FILE")
--------------------------

Provide only an analytical summary of performance issues and clear, short suggestions." \
        > "$OUT_FILE"

    echo "✅ Suggestions saved to: $OUT_FILE"
    echo
done

echo "🎯 All performance suggestions generated successfully in: $OUT_DIR"

