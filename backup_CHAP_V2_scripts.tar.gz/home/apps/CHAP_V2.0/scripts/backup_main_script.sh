#!/bin/bash

source /home/apps/CHAP_V2.0/etc/env_script.sh

#which tau_exec 

#source /home/apps/CHAP_V2.0/etc/set_tau_makefile.sh

#echo "TAU_MAKEFILE="$TAU_MAKEFILE

#rm -rf /home/chap/chap-v2/multiple_source/select*

export TAU_CALLPATH=1

export TAU_VERBOSE=1

#icc /home/apps/CHAP_V2.0/script/selective_instrumentation.c -o /home/apps/CHAP_V2.0/script/selective_instrumentation
icc selective_instrumentation.c  #-o selective_instrumentation

#/home/apps/CHAP_V2.0/script/selective_instrumentation

sh profiling_script.sh 

#python3 auto_suggestion_opt.py

#echo "Profiling Completed !!"
