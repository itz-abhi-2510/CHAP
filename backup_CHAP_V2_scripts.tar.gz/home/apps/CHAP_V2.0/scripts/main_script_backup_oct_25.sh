#!/bin/bash

source /home/apps/CHAP_V2.0/etc/env_script.sh

#which tau_exec

#source /home/apps/CHAP_V2.0/etc/set_tau_makefile.sh

#echo "TAU_MAKEFILE="$TAU_MAKEFILE

#rm -rf /home/chap/chap-v2/multiple_source/select*

export TAU_CALLPATH=1

#export TAU_VERBOSE=1

#icc /home/apps/CHAP_V2.0/script/selective_instrumentation.c -o /home/apps/CHAP_V2.0/script/selective_instrumentation
icc selective_instrumentation.c 

#/home/apps/CHAP_V2.0/scripts/selective_instrumentation
chmod +x a.out

./a.out

#sh profiling_script.sh    ##  Added this line to reduce file size(sed -i '/Thread: Total/,$d' profile.txt )on 10_sept_2025##
sh profile_compile_run_split.sh

#cd /home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin   #####slurm script........
#./final_suggetsion_script.sh      #######October updates wokring fine with slurm script .....


#sh script_llama_cli_for_all_select_nodewise_parallel.sh

#sh script_llama_cli_for_select_2_17_09.sh ######its working and cut the unwanted data 

#sh script_llama_cli_for_select_17_09.sh
#sh profiling_with_tau_exec_split_node_data.sh # updated on 12_09_2025


#sh split_nodC_for_each_select.sh # updated on 12_09_2025 for all select_x dir 



#============ llama_cli cmd 
# ./llama-cli   -m /home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf  -p "Analyze the profiling data and generate optimization suggestions.
#Follow these rules:
#- Focus only on top hotspots consuming most runtime.
#- If IPC is low (<1), suggest vectorization or unrolling.
#- If cache misses are high, suggest tiling, blocking, or data layout optimization.
#- If function is memory-bound, suggest improving memory access or parallelism.
#- If vectorization is missing, suggest compiler flags or loop restructuring.

#Profiling Data:
#$(cat profile_09_09.txt)

#Now provide clear, concise optimization suggestions."
#==================== llama_cli cmd ======================
#python3 auto_suggestion_opt.py

#echo "Profiling Completed !!"

#./split_nod.sh

