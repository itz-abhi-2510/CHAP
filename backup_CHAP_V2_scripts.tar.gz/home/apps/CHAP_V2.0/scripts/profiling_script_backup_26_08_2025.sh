#!/bin/bash
 
# Get the current timestamp ## working used to process source directory path.. ##
timestamp=$(date '+%d_%m_%Y-%H_%M-%S')

# Validate TAU_MAKEFILE is set
if [ -z "$TAU_MAKEFILE" ]; then
    echo "Error: TAU_MAKEFILE is not set. Please source the appropriate TAU setup script."
    exit 1
fi

echo "Choose the application category:"
echo "1. C Applications"
echo "2. Fortran Applications"
read -p "Enter the number corresponding to the category: " app_category

if [[ "$app_category" -eq 1 ]]; then
    echo "Choose the C-based application type:"
    echo "1. OpenMP using C"
    echo "2. MPI using C"
    echo "3. Hybrid (OpenMP + MPI) using C"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_cc.sh"
elif [[ "$app_category" -eq 2 ]]; then
    echo "Choose the Fortran-based application type:"
    echo "1. OpenMP using Fortran"
    echo "2. MPI using Fortran"
    echo "3. Hybrid (OpenMP + MPI) using Fortran"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_f90.sh"
else
    echo "Invalid selection. Exiting."
    exit 1
fi

# Function to find select.tau files
function find_select_tau_files {
    read -p "Enter the directory path containing select.tau files: " tau_dir
    if [ ! -d "$tau_dir" ]; then
        echo "Error: The specified directory does not exist: $tau_dir"
        exit 1
    fi
    select_tau_files=$(ls -1 "$tau_dir"/select*.tau 2>/dev/null)
    if [ -z "$select_tau_files" ]; then
        echo "Error: No select.tau files found in the specified directory."
        exit 1
    fi
    echo -e "\nFound select.tau files: $select_tau_files"
}

# Invoke the select.tau file search function
find_select_tau_files

# Prompt user for the source file directory
read -p "Enter the directory path containing source files: " source_dir

# Validate the directory exists
if [ ! -d "$source_dir" ]; then
    echo "Error: The specified directory does not exist: $source_dir"
    exit 1
fi

# Find all source files in the directory (e.g., .c or .f90)
source_files=$(find "$source_dir" -type f \( -iname "*.c" -o -iname "*.f90" \))
if [ -z "$source_files" ]; then
    echo "Error: No source files found in the specified directory."
    exit 1
fi
echo -e "\nFound source files: $source_files"

# Derive the binary file name from the first source file
first_source_file=$(echo "$source_files" | head -n 1)
binary_file=$(basename "$first_source_file" | sed 's/\.[^.]*$//')
echo "Binary file name will be: $binary_file"

# Prompt user for number of processes for MPI if applicable
read -p "Enter the number of processes for execution: " num_procs

# Create a main output directory
main_output_dir="/home/apps/CHAP_V2.0/result/${binary_file}_${timestamp}"

#main_output_dir="/home/apps/$(whoami)/CHAP_V2.0/result/${binary_file}_${timestamp}"
#main_output_dir="/home/$(whoami)/chap-v2/multiple_source/result/${binary_file}_${timestamp}" 
mkdir -p "$main_output_dir"

##=====suggestion module======##
# Function to generate optimization suggestions from profile.txt
generate_suggestions() {
    local profile_path="$1"
    local suggestion_output="$2"

    echo "🔍 Optimization Suggestions:" > "$suggestion_output"
    local has_suggestions=0

    awk '
    BEGIN { exclusive = 0 }
    /Exclusive time/ { exclusive = 1; next }
    exclusive == 1 {
        if ($0 !~ /^[[:space:]]*[0-9]/) {
            exclusive = 0
            next
        }
        if (NF >= 7 && $1 + 0 > 5.0) {
            print "- Consider optimizing function/loop: " $7 " (exclusive time: " $1 "%)"
            found = 1
        }
    }
    /MPI_/ {
        if (NF >= 7 && $1 + 0 > 5.0) {
            print "- High MPI overhead in: " $7 " (time: " $1 "%)"
            found = 1
        }
    }
    /omp_/ {
        if (NF >= 7 && $1 + 0 > 5.0) {
            print "- OpenMP region might be inefficient: " $7 " (time: " $1 "%)"
            found = 1
        }
    }
    END {
        if (found != 1) {
            print "✅ No critical optimization hotspots found."
        }
    }
    ' "$profile_path" >> "$suggestion_output"
}
#
# Process each select.tau file
for select_tau_file in $select_tau_files; do
    echo "Processing file: $select_tau_file"
    select_name=$(basename "$select_tau_file" .tau)
    loop_output_dir="$main_output_dir/$select_name"
    mkdir -p "$loop_output_dir"
    
    # Copy source and select.tau files to the loop output directory
    cp $source_files "$loop_output_dir/"
    cp "$select_tau_file" "$loop_output_dir/"
    
    # Change to the loop output directory
    cd "$loop_output_dir" || exit 1
    
    # Compile the application directly without object files
    echo "Compiling source files..."
    if ! $tau_wrapper -optTauSelectFile="$select_name.tau" $source_files -o "$binary_file"; then
        echo "Error: Compilation failed for $select_tau_file."
        continue
    fi
    
    # Execute the application
    if ! mpirun -np "$num_procs" tau_exec -T openmpi -ebs ./$binary_file; then
        echo "Error: Execution failed for $select_tau_file."
        continue
    fi
    
    # Generate and convert profiling data
    echo "Generating profiling data for $select_tau_file..."
    if ! pprof; then
        echo "Error: Profiling failed for $select_tau_file."
        continue
    fi
    
    paraprof --oss profile.* > "$loop_output_dir/profile.txt"
    python3 /home/apps/CHAP_V2.0/scripts/convert_profile_to_csv.py "$loop_output_dir/profile.csv"
    python3 /home/apps/CHAP_V2.0/scripts/convert_csv_to_json.py "$loop_output_dir/profile.json"

   # ✅ Call the Bash-based suggestion generator
    generate_suggestions "$loop_output_dir/profile.txt" "$loop_output_dir/suggestion.txt"

    echo "Results for $select_tau_file stored in $loop_output_dir."
done

echo "All tasks completed. Results are in $main_output_dir."
