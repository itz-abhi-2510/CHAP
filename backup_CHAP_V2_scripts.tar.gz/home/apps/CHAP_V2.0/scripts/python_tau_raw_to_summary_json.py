#!/usr/bin/env python3

import json
import argparse
import os

def parse_tau_profile(input_file, output_file):
    with open(input_file) as f:
        raw = json.load(f)

    openmp_worker_time = 0.0
    hotspots = []

    for entry in raw:
        func = entry.get("function", "")
        excl_percent = float(entry.get("excl_percent", "0").replace("%", ""))
        calls = int(entry.get("calls", "0"))

        # OpenMP worker thread handling (TAKE MAX, NOT SUM)
        if "ompt_thread_worker" in func or "OpenMP_Thread_Type" in func:
            openmp_worker_time = max(openmp_worker_time, excl_percent)

        # User-level hotspot detection
        if not func.startswith(".TAU") and excl_percent > 20:
            hotspots.append({
                "function": func,
                "time_percent": round(excl_percent, 2),
                "calls": calls
            })

    summary = {
        "openmp": {
            "worker_time_percent": round(openmp_worker_time, 2)
        },
        "hotspots": hotspots
    }

    os.makedirs(os.path.dirname(output_file), exist_ok=True)

    with open(output_file, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"[OK] Summary written to: {output_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Convert TAU raw profile.json into summarized tau_summary.json"
    )

    parser.add_argument("-i", "--input", required=True,
                        help="TAU raw profile.json file")
    parser.add_argument("-o", "--output", required=True,
                        help="Output tau_summary.json path")

    args = parser.parse_args()
    parse_tau_profile(args.input, args.output)


if __name__ == "__main__":
    main()

