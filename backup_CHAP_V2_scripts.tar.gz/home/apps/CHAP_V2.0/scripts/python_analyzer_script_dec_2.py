import sys
import csv
import os
import subprocess
import json

TOP_N = 5
PPROF_OUT = "pprof.out"

LLAMA_BIN = "/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"
LLAMA_MODEL = "/home/apps/CHAP_V2.0/dependancy/llama_model/hpc-coder-v2-16b.i1-Q4_K_M.gguf"

SYSTEM_PROMPT = """You are an HPC performance optimization expert.

You analyze profiling data from the TAU profiler for
C/C++/Fortran applications using OpenMP and MPI.

Your task:
- Identify performance bottlenecks
- Provide concrete optimization suggestions
- Focus on compute efficiency, OpenMP scalability, and resource usage

Rules:
- Use short bullet points
- Do not repeat profiling data
- Do not explain profiling tools
- Maximum 8 suggestions
"""

def classify_function(name):
    if name.startswith("MPI_"):
        return "MPI"
    elif "Barrier" in name or "Wait" in name:
        return "Synchronization"
    else:
        return "Compute"

def is_real_function(name):
    ignore_keywords = [
        ".TAU application",
        "taupreload",
        "OpenMP_Thread_Type",
        "int main"
    ]
    return not any(k in name for k in ignore_keywords)

def run_pprof(profile_path):
    if os.path.isdir(profile_path):
        workdir = profile_path
    else:
        workdir = os.path.dirname(profile_path) or "."

    cmd = f"pprof -s -m profile.* > {PPROF_OUT}"
    subprocess.run(cmd, shell=True, cwd=workdir, check=True)

    return os.path.join(workdir, PPROF_OUT)

def parse_pprof(filename):
    functions = []

    with open(filename, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("%Time"):
                continue

            parts = line.split()
            if len(parts) < 5:
                continue

            try:
                functions.append({
                    "percent": float(parts[0]),
                    "exclusive": float(parts[1]),
                    "inclusive": float(parts[2]),
                    "calls": int(parts[3]),
                    "name": " ".join(parts[4:]),
                    "type": classify_function(" ".join(parts[4:]))
                })
            except ValueError:
                continue

    return functions

def generate_json_summary(functions, total_runtime):
    hotspots = []

    for fn in functions[:TOP_N]:
        hotspots.append({
            "function": fn["name"],
            "type": fn["type"],
            "inclusive_time_sec": fn["inclusive"],
            "exclusive_time_sec": fn["exclusive"],
            "percent_runtime": fn["percent"],
            "calls": fn["calls"]
        })

    analysis_hints = []
    top = hotspots[0]

    if top["percent_runtime"] > 50:
        analysis_hints.append("Single compute kernel dominates runtime")

    if top["exclusive_time_sec"] / top["inclusive_time_sec"] > 0.6:
        analysis_hints.append("High exclusive time indicates poor parallel efficiency")

    return {
        "language": "C",
        "parallel_model": ["OpenMP"],
        "total_runtime_sec": total_runtime,
        "hotspots": hotspots,
        "analysis_hints": analysis_hints
    }

def write_prompt(json_summary, workdir):
    prompt_path = os.path.join(workdir, "prompt.txt")

    with open(prompt_path, "w") as f:
        f.write(SYSTEM_PROMPT)
        f.write("\n\nTAU profiling summary:\n\n")
        f.write(json.dumps(json_summary, indent=2))
        f.write("\n\nGenerate optimization suggestions.")

    return prompt_path

def run_llama(prompt_path, workdir):
    suggestions_path = os.path.join(workdir, "suggestions.txt")

    with open(prompt_path, "r") as f:
        prompt_text = f.read()

    cmd = [
        LLAMA_BIN,
        "-m", LLAMA_MODEL,
        "--ctx-size", "4096",   # reduce context
        "--temp", "0.2",
        "--top-p", "0.9",
        "-p", prompt_text
    ]

    print("Running llama.cpp ... this may take some time")

    try:
        with open(suggestions_path, "w") as out:
            subprocess.run(
                cmd,
                stdout=out,
                stderr=subprocess.STDOUT,
                timeout=300,      # ⏱ 5 minutes max
                check=True
            )
    except subprocess.TimeoutExpired:
        print("LLM generation timed out (partial output saved).")

    return suggestions_path


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 hpc_ai_profiler.py <tau_profile_directory>")
        sys.exit(1)

    profile_path = sys.argv[1]
    pprof_file = run_pprof(profile_path)

    functions = parse_pprof(pprof_file)
    functions = [f for f in functions if is_real_function(f["name"])]
    functions.sort(key=lambda x: x["inclusive"], reverse=True)

    total_runtime = functions[0]["inclusive"]

    json_summary = generate_json_summary(functions, total_runtime)

    workdir = os.path.dirname(pprof_file)
    json_path = os.path.join(workdir, "profile_summary.json")

    with open(json_path, "w") as jf:
        json.dump(json_summary, jf, indent=2)

    prompt_path = write_prompt(json_summary, workdir)
    suggestions_path = run_llama(prompt_path, workdir)

    print("JSON summary written to:", json_path)
    print("Suggestions written to:", suggestions_path)

if __name__ == "__main__":
    main()
