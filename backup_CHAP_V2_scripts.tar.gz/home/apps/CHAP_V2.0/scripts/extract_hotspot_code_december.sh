#!/bin/bash

TOP_N=10

read -rp "Enter TAU select directory path (contains profile.*): " PROFILE_DIR
PROFILE_DIR=$(realpath "$PROFILE_DIR")

if [ ! -d "$PROFILE_DIR" ]; then
    echo "Error: Invalid directory"
    exit 1
fi

if ! ls "$PROFILE_DIR"/profile.* &>/dev/null; then
    echo "Error: No profile.* files found"
    exit 1
fi

FUNC_OUT="$PROFILE_DIR/hotspots.functions"
LOOP_OUT="$PROFILE_DIR/hotspots.loops"

echo "Extracting hotspots from $PROFILE_DIR"
echo "--------------------------------------"

(
cd "$PROFILE_DIR" || exit 1

# -------- User Functions --------
#pprof -s | \
#grep -Ev "MPI_|OpenMP|pthread|taupreload|TAU_|application" | \
#grep -E '^[[:space:]]*[0-9]' | \
#awk '{print $NF}' | \
#grep -E '^[A-Za-z_][A-Za-z0-9_]*$' | \
#head -n "$TOP_N" > "$FUNC_OUT"

pprof -s | \
grep -Ev "MPI_|OpenMP|pthread|taupreload|TAU_|application" | \
grep -E '^[[:space:]]*[0-9]' | \
awk '{print $6}' | \
grep -E '^[A-Za-z_][A-Za-z0-9_]*$' | \
grep -v '^C$' | \
head -n "$TOP_N" > "$FUNC_OUT"


# -------- Loop Hotspots --------
pprof -s | \
grep "LOOP" | \
awk '{print $NF}' | \
head -n "$TOP_N" > "$LOOP_OUT"
)

echo "Hotspots written:"
echo "  $FUNC_OUT"
echo "  $LOOP_OUT"
echo "--------------------------------------"
