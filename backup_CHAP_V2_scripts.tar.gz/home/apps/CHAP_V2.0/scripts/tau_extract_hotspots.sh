#!/bin/bash

TOP_N=10

pprof -s | \
grep -Ev "MPI_|OpenMP|pthread" | \
awk 'NR>5 {print $NF}' | \
head -n "$TOP_N" > hotspots.functions

pprof -s | \
grep "LOOP" | \
awk '{print $NF}' | \
head -n "$TOP_N" > hotspots.loops

echo "Functions:"
cat hotspots.functions
echo "Loops:"
cat hotspots.loops

