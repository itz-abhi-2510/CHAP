#!/bin/bash

source /home/apps/CHAP_V2.0/etc/env_script.sh
#source /home/apps/CHAP_V2.0/etc/set_tau_makefile.sh
#echo "TAU_MAKEFILE="$TAU_MAKEFILE
#rm -rf /home/chap/chap-v2/multiple_source/select*

export TAU_PROFILE=1
export TAU_CALLPATH=1
export TAU_PROFILE_OPENMP=1
export TAU_CALLPATH_DEPTH=5
#export TAU_VERBOSE=1

#icc /home/apps/CHAP_V2.0/script/selective_instrumentation.c -o /home/apps/CHAP_V2.0/script/selective_instrumentation
icc selective_instrumentation.c 

#/home/apps/CHAP_V2.0/scripts/selective_instrumentation
chmod +x a.out

./a.out

#sh profiling_script.sh    ##  Added this line to reduce file size(sed -i '/Thread: Total/,$d' profile.txt )on 10_sept_2025##
sh profile_compile_run_split.sh

