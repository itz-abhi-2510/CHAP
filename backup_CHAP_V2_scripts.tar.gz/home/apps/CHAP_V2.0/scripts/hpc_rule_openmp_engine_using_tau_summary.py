import json
import argparse

def deduplicate_hotspots(hotspots):
    unique = {}
    for h in hotspots:
        func = h["function"]
        if func not in unique or h["time_percent"] > unique[func]["time_percent"]:
            unique[func] = h
    return list(unique.values())


def generate_rules(summary):
    suggestions = []

    omp = summary.get("openmp", {})
    worker = omp.get("worker_time_percent", 0)

    if worker > 90:
        suggestions.append(
            "OpenMP worker threads dominate runtime (>90%). "
            "This indicates possible oversubscription or load imbalance. "
            "Reduce OMP_NUM_THREADS and tune scheduling."
        )

    hotspots = deduplicate_hotspots(summary.get("hotspots", []))

    for h in hotspots:
        func = h["function"]

        # Skip TAU/OpenMP internals
        if (
            "OpenMP_Thread_Type" in func
            or "ompt_thread_worker" in func
            or func.startswith(".TAU")
        ):
            continue

        if h["time_percent"] > 50:
            suggestions.append(
                f"Function '{func}' dominates runtime "
                f"({h['time_percent']}%). Prioritize optimization here."
            )

    if not suggestions:
        suggestions.append(
            "No dominant bottlenecks detected. Perform scaling, affinity, and compiler optimization studies."
        )

    return suggestions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", required=True, help="tau_summary.json")
    args = parser.parse_args()

    with open(args.input) as f:
        summary = json.load(f)

    rules = generate_rules(summary)

    print("\n=== Rule-based Suggestions ===\n")
    for s in rules:
        print(f"- {s}")


if __name__ == "__main__":
    main()
