#!/bin/bash

TOP_N=10

read -rp "Enter TAU select directory path (contains profile.*): " PROFILE_DIR
PROFILE_DIR=$(realpath "$PROFILE_DIR")

# -----------------------------
# Validation
# -----------------------------
if [ ! -d "$PROFILE_DIR" ]; then
    echo "Error: Invalid directory: $PROFILE_DIR"
    exit 1
fi

if ! ls "$PROFILE_DIR"/profile.* &>/dev/null; then
    echo "Error: No profile.* files found in $PROFILE_DIR"
    exit 1
fi

echo "Extracting hotspots from:"
echo "  $PROFILE_DIR"
echo "--------------------------------------"

# -----------------------------
# Output files (inside select_x)
# -----------------------------
FUNC_OUT="$PROFILE_DIR/hotspots.functions"
LOOP_OUT="$PROFILE_DIR/hotspots.loops"

# -----------------------------
# Run pprof INSIDE profile dir
# -----------------------------
(
    cd "$PROFILE_DIR" || exit 1

    # -------- Top Functions --------
    pprof -s | \
    grep -Ev "MPI_|OpenMP|pthread" | \
    awk 'NR>5 {print $NF}' | \
    head -n "$TOP_N" > "$FUNC_OUT"

    # -------- Top Loops --------
    pprof -s | \
    grep "LOOP" | \
    awk '{print $NF}' | \
    head -n "$TOP_N" > "$LOOP_OUT"
)

# -----------------------------
# Summary
# -----------------------------
echo "Hotspot extraction completed:"
echo "  Functions → $FUNC_OUT"
echo "  Loops     → $LOOP_OUT"
echo "--------------------------------------"
