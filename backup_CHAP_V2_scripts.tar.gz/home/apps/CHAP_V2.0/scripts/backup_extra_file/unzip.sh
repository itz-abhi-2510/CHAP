#!/bin/bash
ecursively find all .gz files and unzip them in place
find . -type f -name "*.gz" | while read -r file; do
    echo "Unzipping: $file"
    gunzip "$file"
done

