import os
import sys
import json
import re

profiling_dir = sys.argv[1]
input_file = None

# Automatically find a summary text file
for file in os.listdir(profiling_dir):
    if file.startswith("profile") or file.endswith(".txt"):
        input_file = os.path.join(profiling_dir, file)
        break

if not input_file:
    print("No TAU profile file found.")
    sys.exit(1)

with open(input_file) as f:
    content = f.read()

# Example regex-based parser
match = re.search(r'Function:\s+(\S+).*?Exclusive:\s+(\d+\.\d+).*?Inclusive:\s+(\d+\.\d+)', content, re.DOTALL)
if match:
    function = match.group(1)
    exclusive = match.group(2)
    inclusive = match.group(3)
else:
    function = "unknown"
    exclusive = "0"
    inclusive = "0"

parsed = {
    "function": function,
    "exclusive_time": exclusive,
    "inclusive_time": inclusive,
    "parallel_model": "OpenMP/MPI (detect manually)",
    "issues": "High exclusive time; possible loop inefficiency"
}

print(json.dumps(parsed, indent=2))
