import json
from pathlib import Path
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer

# Load the LLaMA model (local or Hugging Face)
MODEL_ID = "meta-llama/Meta-Llama-3-8B-Instruct"  # Use LLaMA 3 model

print("Loading model...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
model = AutoModelForCausalLM.from_pretrained(MODEL_ID)
llama_pipeline = pipeline("text-generation", model=model, tokenizer=tokenizer)

# Step 1: Load profiling summary
PROFILE_FILE = "sample_profile.json"

def load_profile(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)

# Step 2: Create a prompt
def make_prompt(prof_data):
    return f"""You are an HPC performance expert. Analyze this profiling data from an HPC application (written in {prof_data['language']}) using {prof_data['model']} model and suggest specific code-level optimization improvements:

Profiling Summary:
{json.dumps(prof_data['hotspots'], indent=2)}

Respond with suggestions in bullet format with reasons.
"""

# Step 3: Get suggestions from LLaMA
def generate_suggestions(prompt):
    print("\n🔍 Generating optimization suggestions...\n")
    result = llama_pipeline(prompt, max_new_tokens=300, do_sample=True)
    return result[0]['generated_text']

# Main logic
if __name__ == "__main__":
    if not Path(PROFILE_FILE).exists():
        print(f"Profile file '{PROFILE_FILE}' not found. Create one first.")
    else:
        prof_data = load_profile(PROFILE_FILE)
        prompt = make_prompt(prof_data)
        output = generate_suggestions(prompt)
        print("\n📋 Optimization Suggestions:\n")
        print(output)
