#!/bin/bash

INPUT_DIR="$1"
MODEL_NAME="${2:-llama3}"  # Or mistral, openchat, etc.

if [ -z "$INPUT_DIR" ]; then
  echo "Usage: $0 <TAU profiling dir> [ollama_model]"
  exit 1
fi

echo "[*] Parsing TAU profile data from: $INPUT_DIR"
python3 tau_summary_parser.py "$INPUT_DIR" > parsed_data.json

echo "[*] Generating prompt for LLM..."
PROMPT=$(python3 -c "
import json
data = json.load(open('parsed_data.json'))
template = open('prompt_template.txt').read()
print(template.format(**data))
")

echo "[*] Sending prompt to $MODEL_NAME..."
echo "$PROMPT" | ollama run "$MODEL_NAME" > output_suggestions/suggestion.txt

echo "[✓] Suggestion saved in output_suggestions/suggestion.txt"
