#!/usr/bin/env python3
import re
import os

def parse_profile(file_path):
    suggestions = []

    with open(file_path, 'r') as file:
        lines = file.readlines()

    exclusive_block = False

    for i, line in enumerate(lines):
        # Detect "Exclusive time" block
        if 'Exclusive time' in line:
            exclusive_block = True
            continue

        if exclusive_block:
            if not re.match(r'^\s*\d', line):
                exclusive_block = False
                continue

            parts = line.split()
            if len(parts) >= 7:
                try:
                    time = float(parts[0])
                    func = parts[6]
                    if time > 5.0:
                        suggestions.append(f"- Consider optimizing function/loop: {func} (exclusive time: {time}%)")
                except ValueError:
                    continue

        # MPI suggestions
        if 'MPI_' in line:
            try:
                time = float(line.strip().split()[0])
                func = line.strip().split()[6]
                if time > 5.0:
                    suggestions.append(f"- High MPI overhead in: {func} (time: {time}%)")
            except:
                continue

        # OpenMP suggestions
        if 'omp_' in line:
            try:
                time = float(line.strip().split()[0])
                func = line.strip().split()[6]
                if time > 5.0:
                    suggestions.append(f"- OpenMP region might be inefficient: {func} (time: {time}%)")
            except:
                continue

    return suggestions

if __name__ == "__main__":
    input_path = input("Enter full path to profile.txt: ").strip()

    if not os.path.isfile(input_path):
        print(f"❌ Error: File not found at {input_path}")
        exit(1)

    try:
        suggestion_list = parse_profile(input_path)
        if suggestion_list:
            print("🔍 Optimization Suggestions:")
            for s in suggestion_list:
                print(s)
        else:
            print("✅ No critical optimization hotspots found.")
    except Exception as e:
        print(f"❌ An error occurred: {e}")
