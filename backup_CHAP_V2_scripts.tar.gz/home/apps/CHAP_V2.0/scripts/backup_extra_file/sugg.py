import re
import sys
import os

def analyze_profile(file_path):
    suggestions = []
    with open(file_path, 'r') as f:
        data = f.read()

    # Example: Detect long function runtimes
    for line in data.splitlines():
        match = re.match(r'\s*\d+[\s:]+([\w_]+)\s+([\d.]+)', line)
        if match:
            func_name, time = match.groups()
            if float(time) > 10.0:  # threshold in seconds
                suggestions.append(f"Function '{func_name}' is a hotspot (>{time}s). Consider optimizing it.")

    # Add more rules here (e.g., MPI imbalance, OpenMP inefficiency)

    return suggestions

def save_suggestions(suggestions, output_path='suggestion.txt'):
    with open(output_path, 'w') as f:
        if suggestions:
            f.write("\n".join(suggestions))
        else:
            f.write("No major performance issues detected. Good job!")

if __name__ == "__main__":
    # Accept file path from command line or prompt
    if len(sys.argv) > 1:
        profile_file = sys.argv[1]
    else:
        profile_file = input("Enter the path to your profiling output file (e.g., profile.txt): ").strip()

    # Check if file exists
    if not os.path.isfile(profile_file):
        print(f"❌ File not found: {profile_file}")
        sys.exit(1)

    suggestions = analyze_profile(profile_file)
    save_suggestions(suggestions)
    print("✅ Suggestions saved to suggestion.txt")

