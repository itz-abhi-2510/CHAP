#!/usr/bin/env python3
import json
import argparse
import subprocess
from pathlib import Path

#from tau_utils import extract_events

def extract_events(data):
    events = []

    # Case 1: tau_summary.json style
    if isinstance(data, dict) and "timers" in data:
        for t in data["timers"]:
            events.append({
                "name": t.get("name", ""),
                "percentage": t.get("percentage", 0.0)
            })
        return events

    # Case 2: profile.json deep structure
    if isinstance(data, dict) and "profiles" in data:
        for node in data["profiles"].values():
            threads = node.get("threads", {})
            for thread in threads.values():
                funcs = thread.get("functions", [])
                for f in funcs:
                    events.append({
                        "name": f.get("name", ""),
                        "percentage": f.get("percentage", 0.0)
                    })
        return events

    # Case 3: already a list (fallback)
    if isinstance(data, list):
        return data

    return []



# =============================
# Configuration (EDIT ONCE)
# =============================
LLAMA_BIN = "/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"
LLAMA_MODEL = "/home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf"

# =============================
# Utility Functions
# =============================
def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

def deduplicate(items):
    return list(dict.fromkeys(items))

# =============================
# Application Type Detection
# =============================
def detect_app_type(events):
    has_mpi = any("MPI_" in e.get("name", "") for e in events)
    has_openmp = any("OpenMP" in e.get("name", "") or "OMP" in e.get("name", "") for e in events)

    if has_mpi and has_openmp:
        return "HYBRID"
    elif has_mpi:
        return "MPI"
    elif has_openmp:
        return "OPENMP"
    else:
        return "UNKNOWN"

# =============================
# Rule Engines
# =============================
def openmp_rules(events):
    suggestions = []

    for e in events:
        name = e.get("name", "")
        pct = e.get("percentage", 0.0)

        if "OpenMP worker" in name and pct > 80:
            suggestions.append(
                "OpenMP worker threads dominate runtime (>80%). Reduce OMP_NUM_THREADS and tune scheduling."
            )

        if pct > 50 and "Loop" in name:
            suggestions.append(
                f"Loop '{name}' dominates runtime ({pct:.1f}%). Apply loop scheduling, collapse, or vectorization."
            )

    return suggestions

def mpi_rules(events):
    suggestions = []

    for e in events:
        name = e.get("name", "")
        pct = e.get("percentage", 0.0)

        if "MPI_Allreduce" in name and pct > 20:
            suggestions.append(
                "MPI_Allreduce is expensive. Reduce call frequency or overlap with computation."
            )

        if "MPI_Wait" in name and pct > 15:
            suggestions.append(
                "High MPI_Wait time indicates load imbalance or poor overlap. Improve computation/communication overlap."
            )

        if pct > 40 and name.startswith("MPI_"):
            suggestions.append(
                f"{name} dominates MPI time ({pct:.1f}%). Optimize message size or algorithm."
            )

    return suggestions

# =============================
# LLM Refiner
# =============================
def refine_with_llama(rule_suggestions):
    if not rule_suggestions:
        return []

    prompt = (
        "You are an HPC performance expert.\n"
        "Refine the following optimization suggestions to be short, concrete, and actionable.\n\n"
        + "\n".join(f"- {s}" for s in rule_suggestions)
        + "\n\nReturn only refined bullet points."
    )

    cmd = [
        LLAMA_BIN,
        "-m", LLAMA_MODEL,
        "-p", prompt,
        "--temp", "0.2",
        "--top-p", "0.9",
        "-n", "256"
    ]

    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    output = result.stdout.strip()

    refined = [
        line.strip("- ").strip()
        for line in output.splitlines()
        if line.strip().startswith("-")
    ]

    return deduplicate(refined)

# =============================
# Main Pipeline
# =============================
def main():
    parser = argparse.ArgumentParser(description="Unified HPC Rule + LLM Suggester")
    parser.add_argument("-i", "--input", required=True, help="Input tau_summary.json / profile.json")
    parser.add_argument("-o", "--output", required=True, help="Output suggestions JSON file")
    parser.add_argument("--llm", action="store_true", help="Enable LLM refinement")
    args = parser.parse_args()

    data = load_json(args.input)

    # TAU formats vary
    events = extract_events(data)
    
    if not events:
         raise ValueError("Could not extract events from TAU JSON file")

#    events = data.get("events") or data.get("profiles") or data
#    if not isinstance(events, list):
#        raise ValueError("Unsupported TAU JSON format")

    app_type = detect_app_type(events)
    rule_suggestions = []

    if app_type in ("OPENMP", "HYBRID"):
        rule_suggestions.extend(openmp_rules(events))

    if app_type in ("MPI", "HYBRID"):
        rule_suggestions.extend(mpi_rules(events))

    rule_suggestions = deduplicate(rule_suggestions)

    refined = refine_with_llama(rule_suggestions) if args.llm else []

    output = {
        "application_type": app_type,
        "rule_based_suggestions": rule_suggestions,
        "llm_refined_suggestions": refined
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(output, f, indent=2)

    print("=== Application Type ===")
    print(app_type)

    print("\n=== Rule-based Suggestions ===")
    for s in rule_suggestions:
        print(f"- {s}")

    if refined:
        print("\n=== LLM-refined Suggestions ===")
        for s in refined:
            print(f"- {s}")

# =============================
if __name__ == "__main__":
    main()
