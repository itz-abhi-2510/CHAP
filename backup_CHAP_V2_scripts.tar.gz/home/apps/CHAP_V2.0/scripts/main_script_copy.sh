#!/bin/bash

# --------------------------------------------------------
# Environment setup and compilation
# --------------------------------------------------------
source /home/apps/CHAP_V2.0/etc/env_script.sh

export TAU_CALLPATH=1

# Run selective instrumentation
# Compile the instrumentation C code
icc selective_instrumentation.c -o a.out
chmod +x a.out

# Run the instrumented binary
./a.out

# Run the profiling compilation and execution split script
sh profile_compile_run_split.sh

# --------------------------------------------------------
# Ask user for BASE_DIR AFTER profiling
# --------------------------------------------------------
read -p "Enter the base directory containing select_* folders for nodewise suggestion: " BASE_DIR

# Validate input
if [ ! -d "$BASE_DIR" ]; then
    echo "❌Error: Directory '$BASE_DIR' does not exist."
    exit 1
fi

echo "✅Using BASE_DIR: $BASE_DIR"

# --------------------------------------------------------
#  Submit nodewise suggestion jobs for each select_* folder
# --------------------------------------------------------
for SEL_DIR in "$BASE_DIR"/select_*; do
    if [ -d "$SEL_DIR" ]; then
        echo "📤Submitting nodewise suggestion job for $SEL_DIR"
        sbatch /home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/slurm_script_3.sh "$SEL_DIR"
    fi
done

echo "✅ All nodewise suggestion jobs submitted!"
