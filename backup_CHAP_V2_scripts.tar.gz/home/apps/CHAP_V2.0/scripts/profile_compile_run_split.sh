#!/bin/bash

# ============================
#   1. Setup & Input
# ============================

# Get the current timestamp
timestamp=$(date '+%d_%m_%Y-%H_%M-%S')

# Validate TAU_MAKEFILE is set
if [ -z "$TAU_MAKEFILE" ]; then
    echo "Error: TAU_MAKEFILE is not set. Please source the appropriate TAU setup script."
    exit 1
fi

# --- Choose application category ---
echo "Choose the application category:"
echo "1. C Applications"
echo "2. Fortran Applications"
read -p "Enter the number corresponding to the category: " app_category

if [[ "$app_category" -eq 1 ]]; then
    echo "Choose the C-based application type:"
    echo "1. OpenMP using C"  
     
        # Execute the application
    export OMP_NUM_THREADS=4   # Set OpenMP threads (adjust as needed)

    echo "2. MPI using C"
    echo "3. Hybrid (OpenMP + MPI) using C"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_cc.sh"
    elif [[ "$app_category" -eq 2 ]]; then
    echo "Choose the Fortran-based application type:"
    echo "1. OpenMP using Fortran"

    # Execute the application
    export OMP_NUM_THREADS=4   # Set OpenMP threads (adjust as needed)

    echo "2. MPI using Fortran"
    echo "3. Hybrid (OpenMP + MPI) using Fortran"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_f90.sh"
else
    echo "Invalid selection. Exiting."
    exit 1
fi

# --- Find select.tau files ---
function find_select_tau_files {
    read -p "Enter the directory path containing select.tau files: " tau_dir
    if [ ! -d "$tau_dir" ]; then
        echo "Error: The specified directory does not exist: $tau_dir"
        exit 1
    fi
    select_tau_files=$(ls -1 "$tau_dir"/select*.tau 2>/dev/null)
    if [ -z "$select_tau_files" ]; then
        echo "Error: No select.tau files found in the specified directory."
        exit 1
    fi
    echo -e "\nFound select.tau files: $select_tau_files"
}
find_select_tau_files

# --- Prompt for source files directory ---
read -p "Enter the directory path containing source files: " source_dir
if [ ! -d "$source_dir" ]; then
    echo "Error: The specified directory does not exist: $source_dir"
    exit 1
fi

# Find all .c or .f90 files
source_files=$(find "$source_dir" -type f \( -iname "*.c" -o -iname "*.f90" \))
if [ -z "$source_files" ]; then
    echo "Error: No source files found in the specified directory."
    exit 1
fi
echo -e "\nFound source files: $source_files"

# Derive binary name
first_source_file=$(echo "$source_files" | head -n 1)
binary_file=$(basename "$first_source_file" | sed 's/\.[^.]*$//')
echo "Binary file name will be: $binary_file"

# MPI process count
read -p "Enter the number of processes for execution: " num_procs

# Main output directory
main_output_dir="/home/apps/CHAP_V2.0/result/${binary_file}_${timestamp}"
mkdir -p "$main_output_dir"


# ============================
#   2. Process each select_x
# ============================

for select_tau_file in $select_tau_files; do
    echo "=============================================="
    echo " Processing file: $select_tau_file"
    echo "=============================================="

    select_name=$(basename "$select_tau_file" .tau)
    loop_output_dir="$main_output_dir/$select_name"
    mkdir -p "$loop_output_dir"

    # --- Copy files ---
    cp $source_files "$loop_output_dir/"
    cp "$select_tau_file" "$loop_output_dir/"

    cd "$loop_output_dir" || exit 1

    # --- Compilation ---
    echo ">>> Compiling source files with TAU..."
    if ! $tau_wrapper -optTauSelectFile="$select_name.tau" $source_files -o "$binary_file"; then
        echo "Error: Compilation failed for $select_tau_file."
        continue
    fi

    # --- Execution ---
    echo ">>> Running application with mpirun..."
    if ! mpirun -np "$num_procs" tau_exec -T openmpi -ebs ./$binary_file; then
        echo "Error: Execution failed for $select_tau_file."
        continue
    fi

    # --- Profiling report generation ---
    echo ">>> Generating profiling data..."
    if ! pprof; then
        echo "Error: Profiling failed for $select_tau_file."
        continue
    fi
    paraprof --oss profile.* > "$loop_output_dir/profile.txt"

    # --- Clean profile.txt ---
    if [ -f "$loop_output_dir/profile.txt" ]; then
        sed -i.bak '/Thread: Total/,$d' "$loop_output_dir/profile.txt"
    fi

    # --- Convert profile to CSV/JSON ---
    python3 /home/apps/CHAP_V2.0/scripts/convert_profile_to_csv.py "$loop_output_dir/profile.csv"
    python3 /home/apps/CHAP_V2.0/scripts/convert_csv_to_json.py "$loop_output_dir/profile.json"

    # ============================
    #   3. Node-wise Splitting
    # ============================
    input="$loop_output_dir/profile.txt"
    if [ -f "$input" ]; then
        echo ">>> Splitting node-wise data..."
        awk -v outdir="$loop_output_dir" '
        /^Thread: n,c,t/ {
            if (out != "") close(out)
            split($3, arr, ",")
            n=arr[1]
            c=arr[2]
            t=arr[3]
            out = sprintf("%s/node_%s_%s_%s.txt", outdir, n, c, t)
        }
        out != "" { print >> out }
        ' "$input"
        echo "Node-wise files saved in $loop_output_dir"
    else
        echo "Skipping node-wise split (profile.txt not found)"
    fi

    echo ">>> Finished processing $select_tau_file"
done


# ============================
#   4. Completion
# ============================
echo "=============================================="
echo "All tasks completed. Results are in $main_output_dir."
echo "=============================================="
