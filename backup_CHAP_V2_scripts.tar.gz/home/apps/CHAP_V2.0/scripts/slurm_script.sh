#!/bin/bash
#SBATCH --job-name=nodewise_suggestions
#SBATCH --output=nodewise_suggestions_%j.out
#SBATCH --error=nodewise_suggestions_%j.err
#SBATCH --partition=gpu
#SBATCH --gres=gpu:1              # Request 1 GPU
#SBATCH --cpus-per-task=8         # Adjust as needed for parallel llama-cli jobs
#SBATCH --mem=16G                 # Memory allocation
#SBATCH --time=02:00:00           # Job time limit (2 hours)

# ============================================================
# SLURM script to run llama-based suggestion generation on GPU
# ============================================================

# Load required modules or activate environment (edit as needed)
# Example:
# module load cuda/12.2
# module load llama-cli
# or if llama-cli is local, export its path
export PATH=/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin:$PATH

# Define profiling result directory (EDIT THIS)
BASE_DIR="/home/apps/CHAP_V2.0/result/pi_cal_09_10_2025-13_59-12/"
        
# Ensure script is executable
#chmod +x generate_nodewise_suggestions.sh

echo "==============================================================="
echo "🚀 Starting nodewise suggestion generation job"
echo "Profiling directory: $BASE_DIR"
echo "==============================================================="

# Run the main script (non-interactive mode)
# Pass directory path directly (no read prompt)
bash -c "
base_dir=\"$BASE_DIR\"
$(grep -v 'read -p' generate_nodewise_suggestions.sh)
"

echo "==============================================================="
echo "✅ Job completed successfully on GPU node"
echo "==============================================================="

