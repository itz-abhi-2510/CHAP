# ===============================
# Generate Global Suggestions with LLaMA
# ===============================
echo "Generating global suggestions using llama.cpp..."
MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/phind-codellama-34b-v2.Q2_K.gguf"
#MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/all-hands_openhands-lm-32b-v0.1-Q5_K_M.gguf"

# Ask user if they want to save suggestions to a file
read -p "Do you also want to save suggestions into suggestions.txt? (y/n): " save_choice
if [[ "$save_choice" =~ ^[Yy]$ ]]; then
    output_file="$loop_output_dir/suggestions.txt"
    > "$output_file"
    save_to_file=true
    echo "Suggestions will also be saved to $output_file"
else
    save_to_file=false
fi

# Collect all node profiling data into one block
combined_data=""
for file in "$loop_output_dir"/node_*.txt; do
    if [ -f "$file" ]; then
        combined_data+="\n--- $(basename "$file") ---\n"
        combined_data+="$(cat "$file")\n"
    fi
done

# Create global prompt
prompt=$(cat <<EOF
You are an HPC optimization assistant.
Below is profiling data collected from multiple nodes of an OpenMP/MPI application written in C/Fortran.

Profiling Data (all nodes combined):
$combined_data

Task:
- Analyze profiling data globally across all nodes
- Identify cross-node bottlenecks (e.g., MPI imbalance, load imbalance, memory usage, synchronization issues)
- Provide only short, actionable performance optimization suggestions
- Output only in bullet points, no explanations
EOF
)

# Call llama-cli once with combined data
/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli \
    -m "$MODEL_PATH" \
    -p "$prompt" | tee >(if $save_to_file; then cat >> "$output_file"; fi)

echo "✅ Global suggestions generated. Results are in $main_output_dir"
