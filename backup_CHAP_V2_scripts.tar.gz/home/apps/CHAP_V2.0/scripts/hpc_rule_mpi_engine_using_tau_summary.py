import json
import re
import argparse
from pathlib import Path

# ------------------------------
# MPI analysis from TAU JSON
# ------------------------------
def analyze_mpi(profile_json):
    with open(profile_json) as f:
        data = json.load(f)

    mpi_time = 0.0
    wait_time = 0.0
    collective_time = 0.0

    collectives = []
    waits = []

    for entry in data:
        func = entry.get("function", "")
        excl = float(entry.get("excl_percent", "0").replace("%", ""))
        calls = int(entry.get("calls", "0"))

        if func.startswith("MPI_"):
            mpi_time += excl

            if re.search(r"MPI_(Allreduce|Allgather|Barrier|Bcast|Reduce)", func):
                collective_time += excl
                collectives.append({
                    "function": func,
                    "time_percent": excl,
                    "calls": calls
                })

            if re.search(r"MPI_(Wait|Waitall|Test)", func):
                wait_time += excl
                waits.append({
                    "function": func,
                    "time_percent": excl,
                    "calls": calls
                })

    return {
        "mpi": {
            "total_time_percent": round(mpi_time, 2),
            "collective_time_percent": round(collective_time, 2),
            "wait_time_percent": round(wait_time, 2),
            "top_collectives": sorted(
                collectives, key=lambda x: x["time_percent"], reverse=True
            )[:3],
            "top_waits": sorted(
                waits, key=lambda x: x["time_percent"], reverse=True
            )[:3]
        }
    }


# ------------------------------
# MPI rule-based suggestions
# ------------------------------
def mpi_rules(mpi_summary):
    suggestions = []

    mpi = mpi_summary.get("mpi", {})
    total = mpi.get("total_time_percent", 0)
    collective = mpi.get("collective_time_percent", 0)
    wait = mpi.get("wait_time_percent", 0)

    if total > 30:
        suggestions.append(
            f"MPI overhead is high ({total}%). "
            "Investigate communication frequency and overlap with computation."
        )

    if collective > 15:
        suggestions.append(
            f"MPI collectives consume significant time ({collective}%). "
            "Reduce collective frequency, fuse reductions, or use hierarchical collectives."
        )

    if wait > 10:
        suggestions.append(
            f"MPI wait time is high ({wait}%). "
            "This indicates load imbalance or synchronization delays."
        )

    for c in mpi.get("top_collectives", []):
        suggestions.append(
            f"{c['function']} is a major collective hotspot "
            f"({c['time_percent']}%, {c['calls']} calls)."
        )

    for w in mpi.get("top_waits", []):
        suggestions.append(
            f"{w['function']} indicates idle ranks "
            f"({w['time_percent']}%, {w['calls']} calls)."
        )

    if not suggestions:
        suggestions.append(
            "MPI behavior appears balanced. Focus on strong/weak scaling studies."
        )

    return suggestions


# ------------------------------
# Main (CLI)
# ------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="MPI Rule-based Performance Analyzer (TAU JSON)"
    )
    parser.add_argument(
        "-i", "--input",
        required=True,
        help="Path to TAU profile JSON file"
    )
    parser.add_argument(
        "-o", "--output",
        required=True,
        help="Output file path for MPI summary and suggestions (JSON)"
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    mpi_summary = analyze_mpi(input_path)
    suggestions = mpi_rules(mpi_summary)

    final_output = {
        "summary": mpi_summary,
        "suggestions": suggestions
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(final_output, f, indent=2)

    print(f"\nMPI analysis written to: {output_path}")
    print("\n=== MPI Rule-based Suggestions ===\n")
    for s in suggestions:
        print(f"- {s}")


if __name__ == "__main__":
    main()

