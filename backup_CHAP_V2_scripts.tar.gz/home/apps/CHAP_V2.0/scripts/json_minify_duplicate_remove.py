import json
import os

def remove_duplicates(obj):
    """Recursively remove duplicates in lists within JSON."""
    if isinstance(obj, list):
        seen = set()
        new_list = []
        for item in obj:
            item_str = json.dumps(item, sort_keys=True)
            if item_str not in seen:
                seen.add(item_str)
                new_list.append(remove_duplicates(item))  # recurse inside
        return new_list
    elif isinstance(obj, dict):
        return {k: remove_duplicates(v) for k, v in obj.items()}
    else:
        return obj

def clean_json(input_file, output_file):
    # Load JSON file
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Remove duplicates
    data = remove_duplicates(data)

    # Save minified JSON (no spaces/newlines)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))

    print(f"✅ Cleaned JSON written to: {output_file}")

if __name__ == "__main__":
    # Take input file path from user
    input_path = input("Enter input JSON file path: ").strip()
    while not os.path.isfile(input_path):
        print("❌ File not found. Please try again.")
        input_path = input("Enter input JSON file path: ").strip()

    # Take output file path from user
    output_path = input("Enter output JSON file path: ").strip()
    if not output_path.endswith(".json"):
        output_path += ".json"  # ensure correct extension

    # Process JSON
    clean_json(input_path, output_path)
