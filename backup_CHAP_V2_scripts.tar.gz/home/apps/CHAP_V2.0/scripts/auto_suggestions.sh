#!/bin/bash

#=== CONFIGURATION ===#
SRC_DIR="$1"                     # Directory containing source files
SELECT_TAU_FILE="$2"             # Path to select.tau file
OUTPUT_DIR="/home/apps/CHAP_V2.0/result"  # Output directory
APP_NAME="my_app"                # Executable name

#=== CHECK INPUTS ===#
if [[ -z "$SRC_DIR" || -z "$SELECT_TAU_FILE" ]]; then
    echo "Usage: $0 <source_dir> <select.tau_path>"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"

#=== LOOP THROUGH FILES ===#
for src_file in "$SRC_DIR"/*.{c,cpp,f90,f95}; do
    [[ -f "$src_file" ]] || continue
    file_name=$(basename "$src_file")
    base_name="${file_name%.*}"
    build_dir="${OUTPUT_DIR}/${base_name}_build"

    echo "⏳ Profiling $file_name..."

    # Create per-file build directory
    mkdir -p "$build_dir"
    cp "$src_file" "$build_dir/"
    cp "$SELECT_TAU_FILE" "$build_dir/"

    cd "$build_dir" || exit

    # Clean old files
    rm -f $APP_NAME

    # Build with TAU
    if [[ "$file_name" == *.f90 || "$file_name" == *.f95 ]]; then
        tau_f90.sh -optVerbose -optTauSelectFile=select_1.tau -optTauSelectStmt=1 "$file_name" -o $APP_NAME
    else
        tau_cc.sh -optVerbose -optTauSelectFile=select_1.tau -optTauSelectStmt=1 "$file_name" -o $APP_NAME
    fi

    # Run the executable
    ./$APP_NAME > output.txt

    # Generate profile summary
    pprof -s > tau_summary.txt

    # Generate optimization suggestion (basic heuristic)
    echo "🔍 Suggestions for $file_name:" > suggestions.txt
    awk '/Exclusive time/ {
        getline; getline;
        while ($1 ~ /^[0-9]/) {
            func=$6
            time=$1
            if (time > 5.0) print "- Consider optimizing loop/function: " func " (time: " time "%)"
            getline
        }
    }' tau_summary.txt >> suggestions.txt

    echo "✅ Report generated for $file_name at $build_dir"

    cd - > /dev/null
done

echo "🎉 All profiling reports are saved in: $OUTPUT_DIR"
