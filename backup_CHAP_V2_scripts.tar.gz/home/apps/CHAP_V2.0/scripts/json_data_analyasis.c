#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define HIGH_EXCL_THRESHOLD 0.1   // > 0.1 seconds -> critical hotspot
#define MEDIUM_EXCL_THRESHOLD 0.01 // 0.01–0.1 seconds -> needs tuning

void generate_suggestion(double excl_secs, const char* function) {
    if (excl_secs > HIGH_EXCL_THRESHOLD) {
        printf("[CRITICAL] Function '%s' takes %.6f secs. Consider parallelization or algorithm optimization.\n", function, excl_secs);
    } else if (excl_secs > MEDIUM_EXCL_THRESHOLD) {
        printf("[INFO] Function '%s' takes %.6f secs. Moderate impact – check loop nesting, I/O, or memory access.\n", function, excl_secs);
    } else {
        printf("[OK] Function '%s' takes %.6f secs. Low impact.\n", function, excl_secs);
    }
}

void analyze_json(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    rewind(file);

    char* data = (char*)malloc(length + 1);
    if (!data) {
        fclose(file);
        printf("Memory error\n");
        return;
    }

    fread(data, 1, length, file);
    data[length] = '\0';
    fclose(file);

    cJSON* root = cJSON_Parse(data);
    free(data);
    if (!root) {
        printf("Error parsing JSON\n");
        return;
    }

    int size = cJSON_GetArraySize(root);
    for (int i = 0; i < size; i++) {
        cJSON* entry = cJSON_GetArrayItem(root, i);
        cJSON* thread = cJSON_GetObjectItem(entry, "Thread");
        cJSON* excl_secs = cJSON_GetObjectItem(entry, "excl_secs");
        cJSON* function = cJSON_GetObjectItem(entry, "function");

        if (thread && excl_secs && function) {
            double secs = atof(excl_secs->valuestring);
            printf("[Thread %s] ", thread->valuestring);
            generate_suggestion(secs, function->valuestring);
        }
    }

    cJSON_Delete(root);
}

int main() {
    char filename[256];

    printf("Enter the path to the JSON profiling data file: ");
    if (scanf("%255s", filename) != 1) {
        fprintf(stderr, "Error reading filename.\n");
        return 1;
    }

    analyze_json(filename);  // Run analysis
    return 0;
}
