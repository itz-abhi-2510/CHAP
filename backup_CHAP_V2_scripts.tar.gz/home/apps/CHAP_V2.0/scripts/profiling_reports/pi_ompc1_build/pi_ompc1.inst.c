#include <Profile/Profiler.h>

#line 1 "pi_ompc1.c"
#include <stdio.h>
#include <omp.h>

// Function declaration
double calculate_pi(int num_intervals, int num_threads);

int main() {

#line 7

TAU_PROFILE_TIMER(tautimer, "int main() C [{pi_ompc1.c} {7,1}-{24,1}]", " ", TAU_DEFAULT);
#ifndef TAU_MPI
#ifndef TAU_SHMEM
  TAU_PROFILE_SET_NODE(0);
#endif /* TAU_SHMEM */
#endif /* TAU_MPI */
	TAU_PROFILE_START(tautimer);


#line 7
{
    int num_intervals = 10000; // Hardcoded value
    int num_threads = 4;           // Hardcoded value

    printf("Number of intervals: %d\n", num_intervals);
    printf("Number of threads: %d\n", num_threads);

    double start_time = omp_get_wtime();  // Start timing

    double pi = calculate_pi(num_intervals, num_threads);

    double end_time = omp_get_wtime();  // End timing

    printf("Calculated value of π: %.15f\n", pi);
    printf("Total execution time: %f seconds\n", end_time - start_time);

    
#line 23
{ int tau_ret_val =  0;  TAU_PROFILE_STOP(tautimer); return (tau_ret_val); }

#line 23


#line 24

}
	
	TAU_PROFILE_STOP(tautimer);


#line 24
}
