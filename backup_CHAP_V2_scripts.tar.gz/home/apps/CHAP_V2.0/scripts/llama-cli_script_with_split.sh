#!/bin/bash

# ==============================
# Nodewise Suggestions Generator
# ==============================

# Ask user for the directory containing nodewise split files
read -p "Enter the directory containing node_*.txt files: " node_dir

# Validate directory
if [ ! -d "$node_dir" ]; then
    echo "Error: Directory '$node_dir' does not exist!"
    exit 1
fi

# Output suggestions file
output_file="$node_dir/suggestions.txt"
> "$output_file"   # clear file if exists

# Path to your llama model (adjust as needed)
MODEL_PATH = "/home/apps/CHAP_V2.0/dependancy/llama_model/phind-codellama-34b-v2.Q2_K.gguf"
#MODEL_PATH="./models/llama-7b.Q4_K_M.gguf"

# Loop through nodewise split files
for file in "$node_dir"/node_*.txt; do
    if [ -f "$file" ]; then
        echo "=== Suggestions for $(basename "$file") ===" | tee -a "$output_file"
        
        # Run llama-cli on each nodewise file and append output
        llama-cli -m "$MODEL_PATH" -f "$file" >> "$output_file"
        
        echo -e "\n" >> "$output_file"
    fi
done

echo "✅ Suggestions generated and saved in: $output_file"
