#!/bin/bash

# ===========================
# HPC Profiling Automation
# ===========================

# Timestamp
timestamp=$(date '+%d_%m_%Y-%H_%M-%S')

# Validate TAU_MAKEFILE
if [ -z "$TAU_MAKEFILE" ]; then
    echo "Error: TAU_MAKEFILE is not set. Please source the TAU setup script."
    exit 1
fi

# Application Category
echo "Choose the application category:"
echo "1. C Applications"
echo "2. Fortran Applications"
read -p "Enter the number corresponding to the category: " app_category

if [[ "$app_category" -eq 1 ]]; then
    echo "Choose the C-based application type:"
    echo "1. OpenMP using C"
    echo "2. MPI using C"
    echo "3. Hybrid (OpenMP + MPI) using C"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_cc.sh"
elif [[ "$app_category" -eq 2 ]]; then
    echo "Choose the Fortran-based application type:"
    echo "1. OpenMP using Fortran"
    echo "2. MPI using Fortran"
    echo "3. Hybrid (OpenMP + MPI) using Fortran"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_f90.sh"
else
    echo "Invalid selection. Exiting."
    exit 1
fi

# Function to find select.tau files
function find_select_tau_files {
    read -p "Enter the directory path containing select.tau files: " tau_dir
    if [ ! -d "$tau_dir" ]; then
        echo "Error: Directory does not exist: $tau_dir"
        exit 1
    fi
    select_tau_files=$(ls -1 "$tau_dir"/select*.tau 2>/dev/null)
    if [ -z "$select_tau_files" ]; then
        echo "Error: No select.tau files found in: $tau_dir"
        exit 1
    fi
    echo -e "\nFound select.tau files: $select_tau_files"
}
find_select_tau_files

# Source directory
read -p "Enter the directory path containing source files: " source_dir
if [ ! -d "$source_dir" ]; then
    echo "Error: Directory does not exist: $source_dir"
    exit 1
fi

# Find source files
source_files=$(find "$source_dir" -type f \( -iname "*.c" -o -iname "*.f90" \))
if [ -z "$source_files" ]; then
    echo "Error: No source files found in: $source_dir"
    exit 1
fi
echo -e "\nFound source files: $source_files"

# Binary file name
first_source_file=$(echo "$source_files" | head -n 1)
binary_file=$(basename "$first_source_file" | sed 's/\.[^.]*$//')
echo "Binary file name: $binary_file"

# Number of processes
read -p "Enter the number of processes for execution: " num_procs

# Main output directory
main_output_dir="/home/apps/CHAP_V2.0/result/${binary_file}_${timestamp}"
mkdir -p "$main_output_dir"

# Fixed llama.cpp paths
LLAMA_CLI="/home/apps/CHAP_V2.0/dependancy/llama.cpp/build/bin/llama-cli"
MODEL_PATH="/home/apps/CHAP_V2.0/dependancy/llama_model/all-hands_openhands-lm-32b-v0.1-Q5_K_M.gguf"

# Nodewise split script path (still external, you provide this)
read -p "Enter the path to your nodewise split script: " SPLIT_SCRIPT

# ===========================
# Loop over select.tau files
# ===========================
for select_tau_file in $select_tau_files; do
    echo "Processing file: $select_tau_file"
    select_name=$(basename "$select_tau_file" .tau)
    loop_output_dir="$main_output_dir/$select_name"
    mkdir -p "$loop_output_dir"

    # Copy input files
    cp $source_files "$loop_output_dir/"
    cp "$select_tau_file" "$loop_output_dir/"

    cd "$loop_output_dir" || exit 1

    # Compile
    echo "Compiling..."
    if ! $tau_wrapper -optTauSelectFile="$select_name.tau" $source_files -o "$binary_file"; then
        echo "Error: Compilation failed for $select_tau_file."
        continue
    fi

    # Execute
    echo "Running application..."
    if ! mpirun -np "$num_procs" tau_exec -T openmpi -ebs ./$binary_file; then
        echo "Error: Execution failed for $select_tau_file."
        continue
    fi

    # Profiling data
    echo "Generating profiling data..."
    if ! pprof; then
        echo "Error: Profiling failed for $select_tau_file."
        continue
    fi

    paraprof --oss profile.* > "$loop_output_dir/profile.txt"
    python3 /home/apps/CHAP_V2.0/scripts/convert_profile_to_csv.py "$loop_output_dir/profile.csv"
    python3 /home/apps/CHAP_V2.0/scripts/convert_csv_to_json.py "$loop_output_dir/profile.json"

    # ===========================
    # Nodewise splitting
    # ===========================
    echo "Splitting profiling data node-wise..."
    sh "$SPLIT_SCRIPT" "$loop_output_dir/profile.txt" "$loop_output_dir/nodewise_output.txt"

    # ===========================
    # llama.cpp suggestions
    # ===========================
    echo "Generating optimization suggestions with llama.cpp..."
    "$LLAMA_CLI" \
        -m "$MODEL_PATH" \
        -p "$(cat "$loop_output_dir/nodewise_output.txt")" \
        > "$loop_output_dir/suggestions.txt"

    echo "✅ Results stored in $loop_output_dir"
done

echo "All tasks completed. Results in $main_output_dir"
