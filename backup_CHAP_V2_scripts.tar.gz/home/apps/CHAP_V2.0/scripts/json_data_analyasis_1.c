#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cJSON.h"

#define CRITICAL_THRESHOLD 0.5
#define MODERATE_THRESHOLD 0.01

void trim_newline(char *str) {
    size_t len = strlen(str);
    if (len == 0) return;
    if (str[len - 1] == '\n') str[len - 1] = '\0';
}

int function_already_reported(char *function, char reported[][512], int count) {
    for (int i = 0; i < count; i++) {
        if (strcmp(reported[i], function) == 0) return 1;
    }
    return 0;
}

void analyze_json(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    rewind(file);

    char* data = malloc(length + 1);
    fread(data, 1, length, file);
    data[length] = '\0';
    fclose(file);

    cJSON* root = cJSON_Parse(data);
    free(data);
    if (!root) {
        printf("Error parsing JSON\n");
        return;
    }

    printf("\n=== Simplified Suggestions ===\n");

    char reported[1000][512]; // Store reported function names
    int report_count = 0;

    int size = cJSON_GetArraySize(root);
    for (int i = 0; i < size; i++) {
        cJSON* entry = cJSON_GetArrayItem(root, i);
        cJSON* function = cJSON_GetObjectItem(entry, "function");
        cJSON* excl_secs = cJSON_GetObjectItem(entry, "excl_secs");

        if (!function || !excl_secs) continue;

        double time = atof(excl_secs->valuestring);
        char* fname = function->valuestring;

        // Only report each function once
        if (function_already_reported(fname, reported, report_count)) continue;
        strcpy(reported[report_count++], fname);

        // Generate concise suggestion
        if (time >= CRITICAL_THRESHOLD) {
            printf("[CRITICAL] %s – High time (%.3f s). Optimize or parallelize.\n", fname, time);
        } else if (time >= MODERATE_THRESHOLD) {
            printf("[MODERATE] %s – Medium time (%.3f s). Review efficiency.\n", fname, time);
        } else {
            printf("[OK] %s – Time %.3f s. No immediate action needed.\n", fname, time);
        }
    }

    cJSON_Delete(root);
}

int main() {
    char filename[256];

    printf("Enter the path to the JSON profiling data file: ");
    if (scanf("%255s", filename) != 1) {
        fprintf(stderr, "Error reading filename.\n");
        return 1;
    }

    analyze_json(filename);
    return 0;
}

