#!/usr/bin/env python3

import json
import argparse
import os
import glob

def parse_tau_profile(input_file, output_file):
    with open(input_file) as f:
        raw = json.load(f)

    openmp_worker_time = 0.0
    hotspots = []

    for entry in raw:
        func = entry.get("function", "")
        excl_percent = float(entry.get("excl_percent", "0").replace("%", ""))
        calls = int(entry.get("calls", "0"))

        # OpenMP worker thread handling (TAKE MAX, NOT SUM)
        if "ompt_thread_worker" in func or "OpenMP_Thread_Type" in func:
            openmp_worker_time = max(openmp_worker_time, excl_percent)

        # User-level hotspot detection
        if not func.startswith(".TAU") and excl_percent > 20:
            hotspots.append({
                "function": func,
                "time_percent": round(excl_percent, 2),
                "calls": calls
            })

    summary = {
        "openmp": {
            "worker_time_percent": round(openmp_worker_time, 2)
        },
        "hotspots": hotspots
    }

    with open(output_file, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"[OK] Summary written to: {output_file}")


def process_all_select_dirs(base_dir):
    select_dirs = sorted(
        d for d in glob.glob(os.path.join(base_dir, "select_*"))
        if os.path.isdir(d)
    )

    if not select_dirs:
        raise ValueError("No select_* directories found")

    for sel_dir in select_dirs:
        input_json = os.path.join(sel_dir, "profile.json")
        output_json = os.path.join(sel_dir, "tau_summary.json")

        if not os.path.isfile(input_json):
            print(f"[SKIP] profile.json not found in {sel_dir}")
            continue

        parse_tau_profile(input_json, output_json)


def main():
    parser = argparse.ArgumentParser(
        description="Convert TAU profile.json in all select_* directories"
    )

    parser.add_argument(
        "-i", "--input-dir",
        required=True,
        help="Base directory containing select_* folders"
    )

    args = parser.parse_args()
    process_all_select_dirs(args.input_dir)


if __name__ == "__main__":
    main()

