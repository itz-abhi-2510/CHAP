import csv
import json

# Prompt the user for the input CSV file and output JSON file

input_csv = "profile.csv"
output_json = "profile.json"
#input_csv = input("Enter the name of the CSV file (with extension): ").strip()
#output_json = input("Enter the name of the output JSON file (with extension): ").strip()

try:
    # Read the CSV file
    data = []
    with open(input_csv, "r") as csvfile:
        csvreader = csv.DictReader(csvfile)
        for row in csvreader:
            data.append(row)

    # Write to JSON file
    with open(output_json, "w") as jsonfile:
        json.dump(data, jsonfile, indent=4)

    print(f"Data successfully converted to JSON format in {output_json}")

except FileNotFoundError:
    print(f"Error: File '{input_csv}' not found. Please check the file name and try again.")
except Exception as e:
    print(f"An error occurred: {e}")

