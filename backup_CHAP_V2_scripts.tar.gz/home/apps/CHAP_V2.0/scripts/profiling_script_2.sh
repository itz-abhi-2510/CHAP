#!/bin/bash

# Get the current timestamp
timestamp=$(date '+%d_%m_%Y-%H_%M-%S')

# Validate TAU_MAKEFILE is set
if [ -z "$TAU_MAKEFILE" ]; then
    echo "Error: TAU_MAKEFILE is not set. Please source the appropriate TAU setup script."
    exit 1
fi

# === Loop-level profiling specific TAU environment variables ===
export TAU_PROFILE=1
export TAU_TRACE=0
export TAU_CALLPATH=1
export TAU_CALLPATH_DEPTH=5
export TAU_METRICS=TIME
export TAU_PROFILE_FORMAT=merged
export TAU_OPTIONS="-optVerbose -optCompInst"

# Application selection
echo "Choose the application category:"
echo "1. C Applications"
echo "2. Fortran Applications"
read -p "Enter the number corresponding to the category: " app_category

if [[ "$app_category" -eq 1 ]]; then
    echo "Choose the C-based application type:"
    echo "1. OpenMP using C"
    echo "2. MPI using C"
    echo "3. Hybrid (OpenMP + MPI) using C"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_cc.sh"
elif [[ "$app_category" -eq 2 ]]; then
    echo "Choose the Fortran-based application type:"
    echo "1. OpenMP using Fortran"
    echo "2. MPI using Fortran"
    echo "3. Hybrid (OpenMP + MPI) using Fortran"
    read -p "Enter the number corresponding to the application type: " app_type
    tau_wrapper="tau_f90.sh"
else
    echo "Invalid selection. Exiting."
    exit 1
fi

# Function to find select.tau files
function find_select_tau_files {
    read -p "Enter the directory path containing select.tau files: " tau_dir
    if [ ! -d "$tau_dir" ]; then
        echo "Error: The specified directory does not exist: $tau_dir"
        exit 1
    fi
    select_tau_files=$(ls -1 "$tau_dir"/select*.tau 2>/dev/null)
    if [ -z "$select_tau_files" ]; then
        echo "Error: No select.tau files found in the specified directory."
        exit 1
    fi
    echo -e "\nFound select.tau files: $select_tau_files"
}

# Invoke the select.tau file search function
find_select_tau_files

# Prompt user for the source file directory
read -p "Enter the directory path containing source files: " source_dir

# Validate the directory exists
if [ ! -d "$source_dir" ]; then
    echo "Error: The specified directory does not exist: $source_dir"
    exit 1
fi

# Find all source files in the directory (.c or .f90)
source_files=$(find "$source_dir" -type f \( -iname "*.c" -o -iname "*.f90" \))
if [ -z "$source_files" ]; then
    echo "Error: No source files found in the specified directory."
    exit 1
fi
echo -e "\nFound source files: $source_files"

# Derive the binary file name from the first source file
first_source_file=$(echo "$source_files" | head -n 1)
binary_file=$(basename "$first_source_file" | sed 's/\.[^.]*$//')
echo "Binary file name will be: $binary_file"

# Prompt for number of processes
read -p "Enter the number of processes for execution: " num_procs

# Create main result directory
main_output_dir="/home/apps/CHAP_V2.0/result/${binary_file}_${timestamp}"
mkdir -p "$main_output_dir"

# Process each select.tau file
for select_tau_file in $select_tau_files; do
    echo "Processing file: $select_tau_file"
    select_name=$(basename "$select_tau_file" .tau)
    loop_output_dir="$main_output_dir/$select_name"
    mkdir -p "$loop_output_dir"

    # Copy source and select.tau files
    cp $source_files "$loop_output_dir/"
    cp "$select_tau_file" "$loop_output_dir/"

    # Change to loop output directory
    cd "$loop_output_dir" || exit 1

    # Compile with TAU and loop-level flags
    echo "Compiling source files..."
    if ! $tau_wrapper $TAU_OPTIONS -optTauSelectFile="$select_name.tau" $source_files -o "$binary_file"; then
        echo "Error: Compilation failed for $select_tau_file."
        continue
    fi

    # Execute application
    if ! mpirun -np "$num_procs" tau_exec -T openmpi -ebs ./$binary_file; then
        echo "Error: Execution failed for $select_tau_file."
        continue
    fi

    # Generate profiling output
    echo "Generating profiling data..."
    if ! pprof; then
        echo "Error: Profiling failed."
        continue
    fi

    # Save profiling results
    paraprof --oss profile.* > "$loop_output_dir/profile.txt"
    pprof -l profile.* > "$loop_output_dir/profile_loops.txt"

    # Convert and suggest
    python3 /home/apps/CHAP_V2.0/script/convert_profile_to_csv.py "$loop_output_dir/profile.csv"
    python3 /home/apps/CHAP_V2.0/script/convert_csv_to_json.py "$loop_output_dir/profile.json"
    python3 /home/apps/CHAP_V2.0/script/suggest_optimizations.py > "$loop_output_dir/suggestion.txt" 2>&1

    echo "Results for $select_tau_file stored in $loop_output_dir."
done

echo "All tasks completed. Results are in $main_output_dir."
