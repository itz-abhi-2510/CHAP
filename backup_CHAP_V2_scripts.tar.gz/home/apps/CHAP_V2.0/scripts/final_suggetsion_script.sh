#!/bin/bash

# Script: generate_nodewise_suggestions.sh
# Purpose: Generate one suggestion per select_* directory
#          and show all suggestions together at the end.

# Ask user for the main profiling output directory
read -p "Enter the path to the main profiling output directory: " base_dir

# Validate directory
if [ ! -d "$base_dir" ]; then
    echo "Error: Directory '$base_dir' not found!"
    exit 1
fi

echo
echo "==============================================================="
echo "🔍 Processing profiling data under: $base_dir"
echo "==============================================================="
echo

# Array to store paths of all generated suggestion files
declare -a suggestion_files

# Step 1: Generate suggestions for each select_* directory
for select_dir in "$base_dir"/select_*; do
    [ -d "$select_dir" ] || continue
    select_name=$(basename "$select_dir")

    echo ">>> Processing $select_name ..."

    combined_file="$select_dir/${select_name}_combined.txt"
    output_file="$select_dir/${select_name}_suggestions.txt"

    # Combine all node files
    cat "$select_dir"/node.*.txt > "$combined_file"

    # Generate suggestion using model
     
     /llama-cli \
    -m /home/apps/CHAP_V2.0/dependancy/llama_model/mistral-7b-instruct-v0.1.Q3_K_L.gguf  \
    -p "You are an HPC performance advisor. Analyze the profiling data and generate optimization suggestions.
       Follow these rules:
       - Focus only on top hotspots consuming most runtime.
       - If IPC is low (<1), suggest vectorization or unrolling.
       - If cache misses are high, suggest tiling, blocking, or data layout optimization.
       - If function is memory-bound, suggest improving memory access or parallelism.
       - If vectorization is missing, suggest compiler flags or loop restructuring.
       Profiling Data: $(cat "$profile_path")
       Now provide clear, concise optimization suggestions." \
       > "$temp_file"  2>/dev/null


    # Clean up combined file
    rm -f "$combined_file"

    # Store suggestion file path for later display
    suggestion_files+=("$output_file")

    echo "✅ Suggestions saved: $output_file"
    echo
done

# Step 2: Display all suggestions together at the end
echo
echo "==============================================================="
echo "📘 FINAL SUGGESTION SUMMARY"
echo "==============================================================="

for file in "${suggestion_files[@]}"; do
    if [ -f "$file" ]; then
        select_name=$(basename "$file" "_suggestions.txt")
        echo
        echo "---------------------------------------------------------------"
        echo "🔹 Suggestions for $select_name:"
        echo "---------------------------------------------------------------"
        cat "$file"
        echo
    fi
done

echo "==============================================================="
echo "🎯 All suggestions displayed successfully!"
echo "==============================================================="
