#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <regex.h>
#include <dirent.h>
#include <sys/stat.h>        //chmod(tau_filename, 0777); //used for select.tau file permission

#define MAX_LINE 1024
#define MAX_FILES 100

typedef struct {
    char type[50];
    int start_line;
    int end_line;
} LoopBlock;

LoopBlock *blocks = NULL;
int block_count = 0;
int block_capacity = 10;

int *stack = NULL;
int stack_top = -1;
int stack_capacity = 10;
int nested_level = 0;

const char *start_patterns[] = {
    "^\\s*!.*\\$omp\\s+do",
    "^\\s*!.*\\$omp\\s+parallel\\s+do",
    "^\\s*do\\b",
    "^\\s*if\\b",
    "^\\s*(if\\s*\\(.*\\)\\s*\\{|else\\s*\\{)",
    "^\\s*#pragma\\s+omp\\s+for",
    "^\\s*for\\s*\\(.*\\)",
    "^\\s*while\\s*\\(.*\\)"
};

const char *end_patterns[] = {
    "^\\s*!.*\\$omp\\s+end\\s+do",
    "^\\s*!\\$omp\\s+end\\s+parallel\\s+do",
    "^\\s*end\\s*do\\b",
    "^\\s*end\\s*if\\b",
    "^\\s*}"
};

void push_stack(int line_num) {
    if (nested_level == 0) {
        if (stack_top + 1 >= stack_capacity) {
            stack_capacity *= 2;
            stack = realloc(stack, stack_capacity * sizeof(int));
            if (!stack) {
                printf("Error: Memory allocation failed for stack.\n");
                exit(EXIT_FAILURE);
            }
        }
        stack[++stack_top] = line_num;
    }
    nested_level++;
}

int pop_stack() {
    if (nested_level > 0) {
        nested_level--;
    }
    if (nested_level == 0 && stack_top >= 0) {
        return stack[stack_top--];
    }
    return -1;
}

void add_block(int start_line, int end_line) {
    if (block_count >= block_capacity) {
        block_capacity *= 2;
        blocks = realloc(blocks, block_capacity * sizeof(LoopBlock));
        if (!blocks) {
            printf("Error: Memory allocation failed for blocks.\n");
            exit(EXIT_FAILURE);
        }
    }
    sprintf(blocks[block_count].type, "Outermost Loop %d", block_count + 1);
    blocks[block_count].start_line = start_line;
    blocks[block_count].end_line = end_line;
    block_count++;
}

void detect_outermost_loops(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Error: Cannot open file %s\n", filename);
        return;
    }

    char line[MAX_LINE];
    int line_num = 0;

    block_count = 0;
    stack_top = -1;
    nested_level = 0;

    blocks = malloc(block_capacity * sizeof(LoopBlock));
    stack = malloc(stack_capacity * sizeof(int));
    if (!blocks || !stack) {
        printf("Error: Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }

    while (fgets(line, sizeof(line), file)) {
        line_num++;

        for (int i = 0; i < sizeof(start_patterns) / sizeof(start_patterns[0]); i++) {
            regex_t regex;
            regcomp(&regex, start_patterns[i], REG_ICASE | REG_EXTENDED);
            if (regexec(&regex, line, 0, NULL, 0) == 0) {
                push_stack(line_num);
            }
            regfree(&regex);
        }

        for (int i = 0; i < sizeof(end_patterns) / sizeof(end_patterns[0]); i++) {
            regex_t regex;
            regcomp(&regex, end_patterns[i], REG_ICASE | REG_EXTENDED);
            if (regexec(&regex, line, 0, NULL, 0) == 0) {
                int start_line = pop_stack();
                if (start_line != -1) {
                    add_block(start_line, line_num);
                }
            }
            regfree(&regex);
        }
    }
    fclose(file);
}

void generate_select_tau(const char *filename, const char *output_dir) {
    char *base_filename = strrchr(filename, '/');
    if (base_filename)
        base_filename++;
    else
        base_filename = (char *)filename;

    char tau_filename[512];
    static int file_count = 1;

    for (int i = 0; i < block_count; i++) {
        sprintf(tau_filename, "%s/select_%d.tau", output_dir, file_count++);
        FILE *tau_file = fopen(tau_filename, "w");

        if (!tau_file) {
            printf("Error: Cannot create %s\n", tau_filename);
            return;
        }

        fprintf(tau_file, "BEGIN_INSTRUMENT_SECTION\n");
        fprintf(tau_file, "dynamic phase name=\"%s\" file=\"%s\" line=%d to line=%d\n", blocks[i].type, base_filename, blocks[i].start_line, blocks[i].end_line);
        fprintf(tau_file, "END_INSTRUMENT_SECTION\n");
        fclose(tau_file);

        chmod(tau_filename, 0777);
        
        printf("Generated: %s\n", tau_filename);
    }
}

int main() {
    char input_dir[256], output_dir[256];
    printf("Enter the source files directory: ");
    scanf("%255s", input_dir);
    printf("Enter the output directory for select.tau files: ");
    scanf("%255s", output_dir);

    struct dirent *entry;
    DIR *dir = opendir(input_dir);
    if (!dir) {
        printf("Error: Cannot open directory %s\n", input_dir);
        return EXIT_FAILURE;
    }

    char filepath[512];
    while ((entry = readdir(dir))) {
        if (strstr(entry->d_name, ".c") || strstr(entry->d_name, ".f90")) {
            snprintf(filepath, sizeof(filepath), "%s/%s", input_dir, entry->d_name);
            printf("Processing file: %s\n", filepath);
            detect_outermost_loops(filepath);

            if (block_count > 0) {
                generate_select_tau(filepath, output_dir);
            } else {
                printf("No outermost loops detected in %s.\n", filepath);
            }
        }
    }
    closedir(dir);
    free(blocks);
    free(stack);
    return EXIT_SUCCESS;
}
