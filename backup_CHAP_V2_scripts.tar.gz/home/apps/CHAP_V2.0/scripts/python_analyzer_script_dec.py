import sys
import csv
import os
import subprocess

TOP_N = 10
PPROF_OUT = "pprof.out"

def classify_function(name):
    if name.startswith("MPI_"):
        return "MPI"
    elif "Barrier" in name or "Wait" in name:
        return "Synchronization"
    else:
        return "Compute"

def is_real_function(name):
    ignore_keywords = [
        ".TAU application",
        "taupreload",
        "OpenMP_Thread_Type",
        "int main"
    ]
    return not any(k in name for k in ignore_keywords)

def run_pprof(profile_path):
    """
    Runs pprof on TAU profile files and generates pprof.out
    """
    if not os.path.exists(profile_path):
        print(f"Error: Path does not exist: {profile_path}")
        sys.exit(1)

    # If user gives directory, go there
    if os.path.isdir(profile_path):
        workdir = profile_path
    else:
        workdir = os.path.dirname(profile_path) or "."

    print(f"Running pprof in: {workdir}")

    cmd = f"pprof -s -m profile.* > {PPROF_OUT}"

    try:
        subprocess.run(cmd, shell=True, cwd=workdir, check=True)
    except subprocess.CalledProcessError:
        print("Error: Failed to run pprof. Ensure TAU environment is sourced.")
        sys.exit(1)

    return os.path.join(workdir, PPROF_OUT)

def parse_pprof(filename):
    functions = []

    with open(filename, "r") as f:
        lines = f.readlines()

    for line in lines:
        line = line.strip()
        if not line or line.startswith("%Time"):
            continue

        parts = line.split()
        if len(parts) < 5:
            continue

        try:
            percent = float(parts[0])
            exclusive = float(parts[1])
            inclusive = float(parts[2])
            calls = int(parts[3])
            name = " ".join(parts[4:])

            functions.append({
                "name": name,
                "percent": percent,
                "exclusive": exclusive,
                "inclusive": inclusive,
                "calls": calls,
                "type": classify_function(name)
            })
        except ValueError:
            continue

    return functions

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 parse_pprof.py <profile_directory_or_file>")
        sys.exit(1)

    profile_input = sys.argv[1]

    # Step 1: Run pprof
    pprof_file = run_pprof(profile_input)

    # Step 2: Parse pprof output
    functions = parse_pprof(pprof_file)
    
    # Filter TAU internal functions
    functions = [fn for fn in functions if is_real_function(fn["name"])]

    functions.sort(key=lambda x: x["inclusive"], reverse=True)

    print("\n=== TOP HOTSPOTS (by Inclusive Time) ===\n")
    for i, fn in enumerate(functions[:TOP_N], 1):
        print(f"{i}. {fn['name']}")
        print(f"   Type       : {fn['type']}")
        print(f"   Inclusive  : {fn['inclusive']} s")
        print(f"   Exclusive  : {fn['exclusive']} s")
        print(f"   Calls      : {fn['calls']}")
        print(f"   % Time     : {fn['percent']}\n")

    # Step 3: Write CSV
    csv_path = os.path.join(os.path.dirname(pprof_file), "tau_hotspot_report.csv")
    with open(csv_path, "w", newline="") as csvfile:
        fieldnames = ["name", "type", "inclusive", "exclusive", "calls", "percent"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for fn in functions:
            writer.writerow(fn)

    print(f"Report written to {csv_path}")

if __name__ == "__main__":
    main()
